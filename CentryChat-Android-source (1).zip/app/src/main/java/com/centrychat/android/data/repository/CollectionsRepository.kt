package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.CollectionDto
import com.centrychat.android.data.model.CollectionItemsResponse
import com.centrychat.android.data.model.CollectionsListResponse
import com.centrychat.android.data.model.safeApiCall

/**
 * Collections repository — wraps `/api/v1/collections/[endpoint]`.
 *
 * Polymorphic save-for-later system: a user can save posts, articles, and
 * profiles into named collections (max 100 collections/user, max 1000 items
 * per collection — admin-configurable).
 */
class CollectionsRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** List the current user's collections. */
    suspend fun getCollections(limit: Int = 50): CollectionsListResponse =
        safeApiCall { api.getCollections(limit = limit) }

    /** Create a new collection. */
    suspend fun createCollection(
        name: String,
        description: String? = null,
        visibility: String = "PRIVATE",
    ): CollectionDto {
        val body = mapOf<String, String?>(
            "name" to name,
            "description" to description,
            "visibility" to visibility,
        )
        return safeApiCall { api.createCollection(body = body, origin = origin) }
    }

    /** Fetch a single collection by ID. */
    suspend fun getCollection(id: String): CollectionDto =
        safeApiCall { api.getCollection(id) }

    /** Delete a collection. */
    suspend fun deleteCollection(id: String): Boolean {
        safeApiCall { api.deleteCollection(id = id, origin = origin) }
        return true
    }

    /** Fetch items in a collection (posts, articles, profiles). */
    suspend fun getItems(id: String, limit: Int = 50): CollectionItemsResponse =
        safeApiCall { api.getCollectionItems(id = id, limit = limit) }

    /** Add an item to a collection. */
    suspend fun addItem(
        collectionId: String,
        itemType: String,
        itemId: String,
    ): Boolean {
        val body = mapOf<String, String?>(
            "itemType" to itemType,
            "itemId" to itemId,
        )
        safeApiCall { api.addCollectionItem(id = collectionId, body = body, origin = origin) }
        return true
    }

    /** Remove an item from a collection. */
    suspend fun removeItem(collectionId: String, itemId: String): Boolean {
        safeApiCall {
            api.removeCollectionItem(id = collectionId, itemId = itemId, origin = origin)
        }
        return true
    }
}
