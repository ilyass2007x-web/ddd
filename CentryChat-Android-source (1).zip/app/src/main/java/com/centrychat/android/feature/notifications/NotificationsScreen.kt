package com.centrychat.android.feature.notifications

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Reply
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.centrychat.android.R
import com.centrychat.android.core.util.TimeFormatter
import com.centrychat.android.data.model.NotificationDto
import com.centrychat.android.rememberNotificationsViewModel
import com.centrychat.android.ui.components.CentryChatAvatar
import com.centrychat.android.ui.components.EmptyState
import com.centrychat.android.ui.components.ErrorState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsScreen(
    contentPadding: PaddingValues,
    onUserClick: (String) -> Unit,
    onPostClick: (String) -> Unit,
    onArticleClick: (String) -> Unit,
) {
    val viewModel = rememberNotificationsViewModel()
    val state by viewModel.state.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()

    val shouldLoadMore by remember {
        derivedStateOf {
            val lastVisibleIndex = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            val total = listState.layoutInfo.totalItemsCount
            total > 0 && lastVisibleIndex >= total - 3
        }
    }
    LaunchedEffect(shouldLoadMore) {
        if (shouldLoadMore) viewModel.loadMore()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.notifications_title)) },
                actions = {
                    IconButton(onClick = { viewModel.markAllRead() }) {
                        Icon(Icons.Filled.DoneAll, contentDescription = stringResource(R.string.notifications_action_mark_all_read))
                    }
                },
            )
        },
    ) { padding ->
        Box(modifier = Modifier
            .fillMaxSize()
            .padding(padding)) {
            when {
                state.isLoading && state.items.isEmpty() -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
                state.error != null && state.items.isEmpty() -> {
                    ErrorState(message = state.error!!, onRetry = viewModel::refresh)
                }
                state.isEmpty -> {
                    EmptyState(message = stringResource(R.string.notifications_empty))
                }
                else -> {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                    ) {
                        items(state.items) { notification ->
                            NotificationRow(
                                notification = notification,
                                onUserClick = onUserClick,
                                onClick = {
                                    if (!notification.read) viewModel.markRead(notification.id)
                                    notification.targetType?.let { type ->
                                        notification.targetId?.let { id ->
                                            when (type) {
                                                "POST" -> onPostClick(id)
                                                "ARTICLE" -> onArticleClick(id)
                                            }
                                        }
                                    }
                                },
                            )
                        }
                        if (state.isLoadingMore) {
                            item {
                                Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationRow(
    notification: NotificationDto,
    onUserClick: (String) -> Unit,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (!notification.read) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary),
            )
            Spacer(Modifier.size(8.dp))
        } else {
            Spacer(Modifier.size(16.dp))
        }

        val icon = when (notification.type) {
            "LIKE" -> Icons.Filled.Favorite
            "FOLLOW" -> Icons.Filled.Person
            "COMMENT", "REPLY" -> Icons.Filled.Reply
            else -> Icons.Filled.Person
        }
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp),
        )
        Spacer(Modifier.size(12.dp))

        Column(Modifier.weight(1f)) {
            if (notification.sender != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CentryChatAvatar(
                        fullName = notification.sender.fullName,
                        avatarColor = null,
                        avatarUrl = notification.sender.avatarUrl,
                        onClick = { onUserClick(notification.sender.username) },
                        size = 28.dp,
                    )
                    Spacer(Modifier.size(8.dp))
                    Text(
                        text = notification.sender.fullName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Spacer(Modifier.size(4.dp))
                    Text(
                        text = "· ${TimeFormatter.relative(notification.createdAt)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            val text = notification.message ?: notification.title ?: "New activity"
            Text(
                text = text,
                style = MaterialTheme.typography.bodyMedium,
                color = if (notification.read) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}
