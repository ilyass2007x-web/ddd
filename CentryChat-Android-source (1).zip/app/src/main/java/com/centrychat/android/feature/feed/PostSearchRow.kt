package com.centrychat.android.feature.feed

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.centrychat.android.core.util.TextUtils
import com.centrychat.android.core.util.TimeFormatter
import com.centrychat.android.data.model.PostDto

/**
 * A compact post row used in search results (less dense than the feed card).
 */
@Composable
fun PostSearchRow(
    post: PostDto,
    onClick: () -> Unit,
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(
                text = "@${post.author.username} · ${TimeFormatter.relative(post.createdAt)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = TextUtils.truncate(post.content, 200),
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 3,
            )
        }
    }
}
