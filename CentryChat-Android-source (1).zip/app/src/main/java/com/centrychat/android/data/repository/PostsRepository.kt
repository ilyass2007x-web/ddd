package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.CommentDto
import com.centrychat.android.data.model.CommentsResponse
import com.centrychat.android.data.model.PagedPostsResponse
import com.centrychat.android.data.model.PostDto
import com.centrychat.android.data.model.ToggleLikeResponse
import com.centrychat.android.data.model.safeApiCall

/**
 * Posts repository.
 *
 * Wraps the posts + post-comments + post-likes endpoints. The Origin header
 * is passed on every state-changing call to satisfy the backend's CSRF check.
 *
 * ERROR HANDLING: every API call goes through [safeApiCall] which extracts
 * the structured `error.message` from non-2xx responses (e.g. "Post not
 * found." on a 404). Without this, the ViewModel would display a generic
 * "HTTP 404 ..." string from Retrofit's default HttpException message.
 */
class PostsRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** Fetch a paginated list of posts (optionally filtered by author). */
    suspend fun getPosts(
        cursor: String? = null,
        limit: Int = 20,
        authorId: String? = null,
    ): PagedPostsResponse {
        return safeApiCall {
            api.getPosts(
                limit = limit,
                cursor = cursor,
                authorId = authorId,
            )
        }
    }

    /** Fetch a single post by ID. */
    suspend fun getPost(id: String): PostDto {
        return safeApiCall { api.getPost(id) }
    }

    /** Create a new text post. */
    suspend fun createPost(content: String): PostDto {
        return safeApiCall {
            api.createPost(
                body = mapOf("content" to content),
                origin = origin,
            )
        }
    }

    /** Delete a post owned by the current user. */
    suspend fun deletePost(id: String): Boolean {
        safeApiCall { api.deletePost(id = id, origin = origin) }
        return true
    }

    /** Toggle like on a post. Returns (liked, likeCount). */
    suspend fun toggleLike(id: String): ToggleLikeResponse {
        return safeApiCall { api.togglePostLike(id = id, origin = origin) }
    }

    /** Fetch paginated comments for a post (sorted by newest by default). */
    suspend fun getComments(
        postId: String,
        cursor: String? = null,
        limit: Int = 50,
        sort: String = "newest",
    ): CommentsResponse {
        return safeApiCall {
            api.getPostComments(
                id = postId,
                limit = limit,
                cursor = cursor,
                sort = sort,
            )
        }
    }

    /** Create a top-level comment or a reply (when parentCommentId is set). */
    suspend fun createComment(
        postId: String,
        content: String,
        parentCommentId: String? = null,
    ): CommentDto {
        val body = buildMap {
            put("content", content)
            if (parentCommentId != null) put("parentCommentId", parentCommentId)
        }
        return safeApiCall {
            api.createPostComment(
                id = postId,
                body = body,
                origin = origin,
            )
        }
    }

    /** Toggle like on a comment. */
    suspend fun toggleCommentLike(commentId: String): ToggleLikeResponse {
        return safeApiCall { api.toggleCommentLike(id = commentId, origin = origin) }
    }
}
