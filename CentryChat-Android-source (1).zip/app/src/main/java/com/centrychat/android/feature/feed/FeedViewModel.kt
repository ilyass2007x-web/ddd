package com.centrychat.android.feature.feed

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.PaginatedState
import com.centrychat.android.data.model.FeedItemDto
import com.centrychat.android.data.model.PostDto
import com.centrychat.android.data.repository.AuthRepository
import com.centrychat.android.data.repository.FeedRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

/**
 * The unified home feed ViewModel.
 *
 * Pulls the personalized feed from the backend (no client-side ranking —
 * the recommendation algorithm lives entirely in the backend). Supports:
 *   - Initial load
 *   - Pull-to-refresh
 *   - Infinite scroll (load more)
 */
class FeedViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: FeedRepository = appContainer.feedRepository
    private val authRepo: AuthRepository = appContainer.authRepository

    private val _state = kotlinx.coroutines.flow.MutableStateFlow<PaginatedState<FeedItemDto>>(PaginatedState())
    val state: kotlinx.coroutines.flow.StateFlow<PaginatedState<FeedItemDto>> = _state

    init {
        // Auto-load the first page when the ViewModel is created.
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null, endReached = false)
            try {
                val response = repo.getForYou(limit = 20)
                _state.value = PaginatedState(
                    items = response.items,
                    cursor = response.nextCursor,
                    isLoading = false,
                    endReached = response.nextCursor == null,
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Fallback: if the personalized feed fails (e.g. user has no
                // follow graph yet), try the trending feed.
                try {
                    val trending = repo.getTrending(limit = 20)
                    _state.value = PaginatedState(
                        items = trending.items,
                        cursor = trending.nextCursor,
                        isLoading = false,
                        endReached = trending.nextCursor == null,
                    )
                } catch (_: Exception) {
                    _state.value = _state.value.copy(
                        isLoading = false,
                        error = e.message ?: "Could not load feed.",
                    )
                }
            }
        }
    }

    fun loadMore() {
        val current = _state.value
        if (current.isLoadingMore || current.endReached || current.cursor == null) return

        viewModelScope.launch {
            _state.value = current.copy(isLoadingMore = true)
            try {
                val next = repo.getForYouNext(cursor = current.cursor!!, limit = 20)
                _state.value = current.copy(
                    items = current.items + next.items,
                    cursor = next.nextCursor,
                    isLoadingMore = false,
                    endReached = next.nextCursor == null,
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = current.copy(
                    isLoadingMore = false,
                    error = e.message,
                )
            }
        }
    }
}
