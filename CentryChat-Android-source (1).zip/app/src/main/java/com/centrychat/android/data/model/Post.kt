package com.centrychat.android.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * A short Post (text-only, social-media style).
 *
 * Mirrors `PostDTO` in `src/app/api/v1/posts/route.ts`. The backend includes
 * all engagement counts + isLiked + isFollowing for the author in every
 * response, so the client doesn't need to make additional round-trips.
 */
@Serializable
data class PostDto(
    val id: String,
    val content: String,
    @SerialName("createdAt") val createdAt: String,
    @SerialName("updatedAt") val updatedAt: String? = null,
    val author: AuthorDto,
    @SerialName("likeCount") val likeCount: Long = 0,
    @SerialName("commentCount") val commentCount: Long = 0,
    @SerialName("viewCount") val viewCount: Long = 0,
    @SerialName("shareCount") val shareCount: Long = 0,
    @SerialName("isLiked") val isLiked: Boolean = false,
    @SerialName("topicIds") val topicIds: List<String> = emptyList(),
    @SerialName("moderationStatus") val moderationStatus: String = "APPROVED",
)

/**
 * The author info embedded in post + article responses.
 *
 * Includes `isFollowing` + `isFollowedBy` so the client can render the correct
 * follow button state without an additional API call.
 */
@Serializable
data class AuthorDto(
    val id: String,
    val fullName: String,
    val username: String,
    @SerialName("avatarColor") val avatarColor: String? = null,
    @SerialName("avatarUrl") val avatarUrl: String? = null,
    val isVerified: Boolean = false,
    val isFollowing: Boolean = false,
    val isFollowedBy: Boolean = false,
)

/**
 * Response shape for `GET /api/v1/posts` (paginated, cursor-based).
 *
 * `nextCursor` is null when there are no more posts. The client passes it
 * back as `?cursor=...` for the next page.
 */
@Serializable
data class PagedPostsResponse(
    val posts: List<PostDto>,
    @SerialName("nextCursor") val nextCursor: String? = null,
)

/**
 * Response shape for `GET /api/v1/feed/unified` and `GET /api/v1/feed/trending`.
 *
 * The unified feed is a mixed stream of posts + articles (ranked by the
 * backend's recommendation algorithm — the client does NOT re-rank).
 */
@Serializable
data class FeedResponse(
    val items: List<FeedItemDto>,
    @SerialName("nextCursor") val nextCursor: String? = null,
)

/**
 * A single item in the unified feed — either a post or an article.
 *
 * `kind` is "post" or "article" — the client uses this to render the right
 * card layout. The backend always sets this field when generating the feed.
 */
@Serializable
data class FeedItemDto(
    val kind: String = "post",
    val post: PostDto? = null,
    val article: ArticleCardDto? = null,
)

/**
 * Response shape for `POST /api/v1/posts/{id}/like` and the analogous
 * article/comment like endpoints.
 */
@Serializable
data class ToggleLikeResponse(
    val liked: Boolean,
    @SerialName("likeCount") val likeCount: Long,
)
