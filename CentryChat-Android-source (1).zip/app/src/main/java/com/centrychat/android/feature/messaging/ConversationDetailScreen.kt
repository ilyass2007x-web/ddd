package com.centrychat.android.feature.messaging

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.centrychat.android.R
import com.centrychat.android.core.LocalAppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.MessageDto

/**
 * Conversation detail screen — shows the message thread for a single
 * conversation.
 *
 * Renders message bubbles with the sender's avatar on the left for
 * incoming messages, and on the right for outgoing messages.
 *
 * The input bar at the bottom allows sending new text messages via
 * `POST /api/v1/conversations/{id}/messages`.
 *
 * Polling every 15s for new messages (matches the web's MainNav pattern).
 * Real-time socket.io is tracked as a follow-up.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationDetailScreen(
    conversationId: String,
    otherUsername: String,
    onBack: () -> Unit,
) {
    val appContainer = LocalAppContainer.current
    val viewModel = remember { ConversationDetailViewModel(appContainer) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val sendError by viewModel.sendError.collectAsStateWithLifecycle()
    val isSending by viewModel.isSending.collectAsStateWithLifecycle()

    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(conversationId) { viewModel.load(conversationId) }

    // Auto-scroll to the bottom when new messages arrive.
    val messageCount = (state as? UiState.Success)?.data?.size ?: 0
    LaunchedEffect(messageCount) {
        if (messageCount > 0) listState.animateScrollToItem(messageCount - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("@$otherUsername") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    placeholder = { Text(stringResource(R.string.conversation_placeholder)) },
                    modifier = Modifier.weight(1f),
                    maxLines = 4,
                    isError = sendError != null,
                )
                Spacer(Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        viewModel.sendMessage(input)
                        input = ""
                    },
                    enabled = !isSending && input.isNotBlank(),
                ) {
                    if (isSending) {
                        CircularProgressIndicator(modifier = Modifier.height(24.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = stringResource(R.string.conversation_send))
                    }
                }
            }
        },
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            when (val s = state) {
                is UiState.Loading -> Row(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    horizontalArrangement = Arrangement.Center,
                ) { CircularProgressIndicator() }
                is UiState.Error -> Text(
                    s.message,
                    modifier = Modifier.padding(24.dp),
                    color = MaterialTheme.colorScheme.error,
                )
                is UiState.Empty -> Text(
                    stringResource(R.string.conversation_empty),
                    modifier = Modifier.padding(24.dp),
                )
                is UiState.Success -> LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                        horizontal = 12.dp, vertical = 8.dp,
                    ),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(s.data) { msg -> MessageBubble(msg) }
                }
                is UiState.Empty -> {}
            }
            sendError?.let { err ->
                Text(
                    err,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 72.dp),
                )
            }
        }
    }
}

@Composable
private fun MessageBubble(message: MessageDto) {
    // For 1:1 conversations, the current user's messages are right-aligned,
    // the other participant's messages are left-aligned. We don't have the
    // current user's ID directly here, so we use the `sender` field — if
    // absent, we fall back to left-aligned (defensive).
    val isOutgoing = message.sender == null // the backend omits sender on the current user's own messages
    val alignment = if (isOutgoing) Arrangement.End else Arrangement.Start
    val bubbleColor = if (isOutgoing)
        MaterialTheme.colorScheme.primary
    else
        MaterialTheme.colorScheme.surfaceVariant
    val textColor = if (isOutgoing)
        MaterialTheme.colorScheme.onPrimary
    else
        MaterialTheme.colorScheme.onSurface

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = alignment,
    ) {
        Surface(
            color = bubbleColor,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth(0.75f),
        ) {
            Column(Modifier.padding(12.dp)) {
                if (!isOutgoing && message.sender != null) {
                    Text(
                        message.sender.fullName,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = textColor,
                    )
                    Spacer(Modifier.height(4.dp))
                }
                Text(
                    message.content,
                    style = MaterialTheme.typography.bodyMedium,
                    color = textColor,
                )
                if (message.isEdited) {
                    Text(
                        "edited",
                        style = MaterialTheme.typography.bodySmall,
                        color = textColor.copy(alpha = 0.7f),
                    )
                }
            }
        }
    }
}
