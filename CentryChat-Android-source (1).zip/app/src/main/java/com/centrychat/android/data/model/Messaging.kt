package com.centrychat.android.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Messaging DTOs — mirror the shapes returned by `/api/v1/conversations`
 * and `/api/v1/conversations/{id}/messages`.
 *
 * The web app's `lib/messaging.ts` returns these exact shapes — the
 * Android client deserializes them as-is.
 *
 * REAL-TIME NOTE: the web uses socket.io for real-time (typing indicators,
 * presence, message arrival). The Android app uses a polling fallback
 * every 15s — same as the web's MainNav unread-count badge fallback.
 * Real-time socket.io integration is tracked as a follow-up.
 */

@Serializable
data class ConversationsListResponse(
    val conversations: List<ConversationDto> = emptyList(),
)

@Serializable
data class ConversationCreateResponse(
    val conversation: ConversationDto? = null,
)

@Serializable
data class ConversationDto(
    val id: String,
    val type: String = "DIRECT",
    @SerialName("lastMessage") val lastMessage: MessageDto? = null,
    @SerialName("unreadCount") val unreadCount: Long = 0,
    @SerialName("lastReadAt") val lastReadAt: String? = null,
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("updatedAt") val updatedAt: String? = null,
    // The "other participant" for direct conversations — used to render
    // the avatar + name in the conversation list. The backend includes
    // this as `participant` (object) for direct conversations.
    val participant: UserProfileSummary? = null,
    val participants: List<UserProfileSummary> = emptyList(),
)

@Serializable
data class MessagesListResponse(
    val messages: List<MessageDto> = emptyList(),
)

@Serializable
data class MessageDto(
    val id: String,
    val content: String,
    @SerialName("conversationId") val conversationId: String,
    @SerialName("senderId") val senderId: String,
    val sender: UserProfileSummary? = null,
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("updatedAt") val updatedAt: String? = null,
    @SerialName("isEdited") val isEdited: Boolean = false,
    @SerialName("isDeleted") val isDeleted: Boolean = false,
    @SerialName("readAt") val readAt: String? = null,
)
