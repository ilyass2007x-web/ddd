package com.centrychat.android.feature.topics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.TopicDto
import com.centrychat.android.data.repository.TopicsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class TopicsViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: TopicsRepository = appContainer.topicsRepository

    private val _state = MutableStateFlow<UiState<List<TopicDto>>>(UiState.Loading)
    val state: StateFlow<UiState<List<TopicDto>>> = _state.asStateFlow()

    fun load() {
        _state.value = UiState.Loading
        viewModelScope.launch {
            try {
                val topics = repo.getTopics().topics
                _state.value = if (topics.isEmpty()) UiState.Empty else UiState.Success(topics)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = UiState.Error(e.message ?: "Could not load topics.")
            }
        }
    }

    fun toggleFollow(topic: TopicDto) {
        viewModelScope.launch {
            try {
                if (topic.isFollowing) repo.unfollow(topic.slug) else repo.follow(topic.slug)
                load()
            } catch (_: Exception) {}
        }
    }
}
