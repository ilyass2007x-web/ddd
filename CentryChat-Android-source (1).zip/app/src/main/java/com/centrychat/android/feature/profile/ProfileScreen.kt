package com.centrychat.android.feature.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.centrychat.android.R
import com.centrychat.android.core.LocalAppContainer
import com.centrychat.android.core.util.TextUtils
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.UserProfileSummary
import com.centrychat.android.ui.components.CentryChatAvatar
import com.centrychat.android.ui.components.EmptyState
import com.centrychat.android.ui.components.ErrorState
import com.centrychat.android.ui.components.UserRow
import com.centrychat.android.ui.components.VerifiedBadge

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    contentPadding: PaddingValues? = null,
    username: String?,
    isOwnProfile: Boolean,
    onBack: (() -> Unit)? = null,
    onEditProfile: () -> Unit,
    onUserClick: (String) -> Unit,
    onPostClick: (String) -> Unit,
    onArticleClick: ((String) -> Unit)? = null,
    onPlaylistClick: ((String) -> Unit)? = null,
    onFollowersClick: (String) -> Unit,
    onFollowingClick: (String) -> Unit,
    onSettingsClick: () -> Unit,
    onMessageUser: ((userId: String, username: String) -> Unit)? = null,
) {
    val appContainer = LocalAppContainer.current
    val viewModel: ProfileViewModel = viewModel(
        factory = remember {
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T =
                    ProfileViewModel(appContainer) as T
            }
        }
    )

    val state by viewModel.profileState.collectAsStateWithLifecycle()
    val isFollowing by viewModel.isFollowing.collectAsStateWithLifecycle()

    LaunchedEffect(username) { viewModel.loadProfile(username) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(username?.let { "@$it" } ?: stringResource(R.string.nav_profile)) },
                navigationIcon = {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = stringResource(R.string.cd_back_button),
                            )
                        }
                    }
                },
                actions = {
                    if (isOwnProfile) {
                        IconButton(onClick = onSettingsClick) {
                            Icon(Icons.Filled.Settings, contentDescription = null)
                        }
                    }
                },
            )
        },
    ) { padding ->
        Box(modifier = Modifier
            .fillMaxSize()
            .padding(padding)) {
            when (val s = state) {
                UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                is UiState.Error -> ErrorState(message = s.message, onRetry = { viewModel.loadProfile(username) })
                UiState.Empty -> EmptyState(message = "User not found.")
                is UiState.Success -> ProfileContent(
                    profile = s.data,
                    isOwnProfile = isOwnProfile,
                    isFollowing = isFollowing,
                    onToggleFollow = { viewModel.toggleFollow(s.data.username) },
                    onEditProfile = onEditProfile,
                    onFollowersClick = { onFollowersClick(s.data.username) },
                    onFollowingClick = { onFollowingClick(s.data.username) },
                )
            }
        }
    }
}

@Composable
private fun ProfileContent(
    profile: UserProfileSummary,
    isOwnProfile: Boolean,
    isFollowing: Boolean,
    onToggleFollow: () -> Unit,
    onEditProfile: () -> Unit,
    onFollowersClick: () -> Unit,
    onFollowingClick: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CentryChatAvatar(
                fullName = profile.fullName,
                avatarColor = profile.avatarColor,
                avatarUrl = profile.avatarUrl,
                size = 80.dp,
            )
            Spacer(Modifier.size(16.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = profile.fullName,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                    )
                    if (profile.isVerified) {
                        Spacer(Modifier.size(6.dp))
                        VerifiedBadge()
                    }
                }
                Text(
                    text = "@${profile.username}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        if (!profile.bio.isNullOrBlank()) {
            Spacer(Modifier.height(12.dp))
            Text(text = profile.bio, style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
        ) {
            Statistic(
                label = stringResource(R.string.profile_posts),
                count = profile.postsCount,
                onClick = {},
            )
            Statistic(
                label = stringResource(R.string.profile_followers),
                count = profile.followersCount,
                onClick = onFollowersClick,
            )
            Statistic(
                label = stringResource(R.string.profile_following),
                count = profile.followingCount,
                onClick = onFollowingClick,
            )
        }

        Spacer(Modifier.height(16.dp))

        if (isOwnProfile) {
            OutlinedButton(
                onClick = onEditProfile,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(stringResource(R.string.profile_edit))
            }
        } else {
            FilledTonalButton(
                onClick = onToggleFollow,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(if (isFollowing) stringResource(R.string.post_action_unfollow) else stringResource(R.string.post_action_follow))
            }
        }
    }
}

@Composable
private fun Statistic(label: String, count: Long, onClick: () -> Unit) {
    Column(
        modifier = Modifier.clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = TextUtils.compactCount(count),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
        )
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
