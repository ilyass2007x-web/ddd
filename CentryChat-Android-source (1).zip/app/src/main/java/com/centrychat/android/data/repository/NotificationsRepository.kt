package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.NotificationDto
import com.centrychat.android.data.model.NotificationListResponse
import com.centrychat.android.data.model.safeApiCall

/**
 * Notifications repository.
 *
 * Wraps the notifications list + mark-as-read endpoints. The CentryChat
 * backend excludes MESSAGE-type notifications from this list (those are
 * tracked separately via the conversation unread-count badge) — so the
 * activity feed is purely social notifications (likes, follows, comments).
 *
 * ERROR HANDLING: every API call goes through [safeApiCall] which extracts
 * the structured `error.message` from non-2xx responses (e.g. "Notification
 * not found." on a 404). Without this, the ViewModel would display a
 * generic "HTTP ..." string from Retrofit's default HttpException message.
 */
class NotificationsRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** Fetch the first page of notifications. */
    suspend fun getNotifications(limit: Int = 20, unreadOnly: Boolean = false): NotificationListResponse {
        return safeApiCall {
            api.getNotifications(
                limit = limit,
                beforeId = null,
                unread = if (unreadOnly) "true" else null,
            )
        }
    }

    /** Fetch the next page of notifications (cursor = `beforeId`). */
    suspend fun getNotificationsNext(beforeId: String, limit: Int = 20): NotificationListResponse {
        return safeApiCall {
            api.getNotifications(
                limit = limit,
                beforeId = beforeId,
                unread = null,
            )
        }
    }

    /** Mark a single notification as read. */
    suspend fun markRead(id: String): Boolean {
        safeApiCall { api.markNotificationRead(id = id, origin = origin) }
        return true
    }

    /** Mark ALL notifications as read. */
    suspend fun markAllRead(): Boolean {
        safeApiCall { api.markAllNotificationsRead(origin = origin) }
        return true
    }

    /** Convenience: fetch the first page as a flat list. */
    suspend fun getFirstPage(limit: Int = 20): List<NotificationDto> {
        return getNotifications(limit = limit).notifications
    }
}
