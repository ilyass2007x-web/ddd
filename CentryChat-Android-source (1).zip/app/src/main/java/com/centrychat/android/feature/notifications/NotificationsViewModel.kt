package com.centrychat.android.feature.notifications

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.PaginatedState
import com.centrychat.android.data.model.NotificationDto
import com.centrychat.android.data.repository.NotificationsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class NotificationsViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: NotificationsRepository = appContainer.notificationsRepository

    private val _state = MutableStateFlow(PaginatedState<NotificationDto>())
    val state: StateFlow<PaginatedState<NotificationDto>> = _state

    private val _unreadCount = MutableStateFlow(0L)
    val unreadCount: StateFlow<Long> = _unreadCount

    init { refresh() }

    fun refresh() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null, endReached = false)
            try {
                val response = repo.getNotifications(limit = 20)
                _state.value = PaginatedState(
                    items = response.notifications,
                    cursor = if (response.hasMore && response.notifications.isNotEmpty())
                        response.notifications.last().id else null,
                    isLoading = false,
                    endReached = !response.hasMore,
                )
                _unreadCount.value = response.unreadCount
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    isLoading = false,
                    error = e.message ?: "Could not load notifications.",
                )
            }
        }
    }

    fun loadMore() {
        val current = _state.value
        if (current.isLoadingMore || current.endReached || current.cursor == null) return

        viewModelScope.launch {
            _state.value = current.copy(isLoadingMore = true)
            try {
                val response = repo.getNotificationsNext(beforeId = current.cursor!!, limit = 20)
                _state.value = current.copy(
                    items = current.items + response.notifications,
                    cursor = if (response.hasMore && response.notifications.isNotEmpty())
                        response.notifications.last().id else null,
                    isLoadingMore = false,
                    endReached = !response.hasMore,
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = current.copy(isLoadingMore = false, error = e.message)
            }
        }
    }

    fun markRead(id: String) {
        viewModelScope.launch {
            try {
                repo.markRead(id)
                val current = _state.value
                val updated = current.items.map {
                    if (it.id == id) it.copy(read = true) else it
                }
                _state.value = current.copy(items = updated)
                _unreadCount.value = (_unreadCount.value - 1).coerceAtLeast(0)
            } catch (_: Exception) {}
        }
    }

    fun markAllRead() {
        viewModelScope.launch {
            try {
                repo.markAllRead()
                val current = _state.value
                val updated = current.items.map { it.copy(read = true) }
                _state.value = current.copy(items = updated)
                _unreadCount.value = 0
            } catch (_: Exception) {}
        }
    }
}
