package com.centrychat.android.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Comment + Notification + Search + Users-list DTOs.
 */

@Serializable
data class CommentDto(
    val id: String,
    val content: String,
    @SerialName("createdAt") val createdAt: String,
    @SerialName("updatedAt") val updatedAt: String? = null,
    val author: AuthorDto,
    @SerialName("likeCount") val likeCount: Long = 0,
    @SerialName("isLiked") val isLiked: Boolean = false,
    @SerialName("parentCommentId") val parentCommentId: String? = null,
    val replies: List<CommentDto> = emptyList(),
)

@Serializable
data class CommentsResponse(
    val comments: List<CommentDto>,
    @SerialName("nextCursor") val nextCursor: String? = null,
)

@Serializable
data class NotificationDto(
    val id: String,
    val type: String,
    val title: String? = null,
    val message: String? = null,
    val read: Boolean = false,
    @SerialName("readAt") val readAt: String? = null,
    @SerialName("targetType") val targetType: String? = null,
    @SerialName("targetId") val targetId: String? = null,
    @SerialName("conversationId") val conversationId: String? = null,
    @SerialName("messageId") val messageId: String? = null,
    @SerialName("senderId") val senderId: String? = null,
    val sender: NotificationSenderDto? = null,
    val metadata: NotificationMetadata? = null,
    @SerialName("createdAt") val createdAt: String,
)

@Serializable
data class NotificationSenderDto(
    val id: String,
    val fullName: String,
    val username: String,
    @SerialName("avatarColor") val avatarColor: String? = null,
    @SerialName("avatarUrl") val avatarUrl: String? = null,
    val isVerified: Boolean = false,
)

@Serializable
data class NotificationMetadata(
    val postContent: String? = null,
    val commentContent: String? = null,
    val articleTitle: String? = null,
)

@Serializable
data class NotificationListResponse(
    val notifications: List<NotificationDto>,
    @SerialName("unreadCount") val unreadCount: Long = 0,
    val hasMore: Boolean = false,
)

@Serializable
data class SearchAllResponse(
    val users: List<UserProfileSummary> = emptyList(),
    val posts: List<PostDto> = emptyList(),
    val articles: List<ArticleCardDto> = emptyList(),
    val total: Long = 0,
)

@Serializable
data class UsersListResponse(
    val users: List<UserProfileSummary>,
    @SerialName("nextCursor") val nextCursor: String? = null,
)

@Serializable
data class SuggestedUsersResponse(
    val users: List<UserProfileSummary>,
)
