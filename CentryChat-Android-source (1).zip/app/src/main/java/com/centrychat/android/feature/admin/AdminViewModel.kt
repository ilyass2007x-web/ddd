package com.centrychat.android.feature.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.security.Roles
import com.centrychat.android.core.security.Permissions
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.AdminDashboardResponse
import com.centrychat.android.data.model.AdminMyPermissionsResponse
import com.centrychat.android.data.repository.AdminRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Admin dashboard ViewModel.
 *
 * Loads:
 *  - The current admin's role + permission set (`/api/v1/admin/me/permissions`).
 *  - The dashboard overview (`/api/v1/admin/dashboard`).
 *
 * The permission set is used to gate which admin sections are shown in the
 * UI. SUPER_ADMIN short-circuits to "*" → all sections visible.
 */
class AdminViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: AdminRepository = appContainer.adminRepository

    private val _permissionsState = MutableStateFlow<UiState<AdminMyPermissionsResponse>>(UiState.Loading)
    val permissionsState: StateFlow<UiState<AdminMyPermissionsResponse>> = _permissionsState.asStateFlow()

    private val _dashboardState = MutableStateFlow<UiState<AdminDashboardResponse>>(UiState.Loading)
    val dashboardState: StateFlow<UiState<AdminDashboardResponse>> = _dashboardState.asStateFlow()

    fun load() {
        _permissionsState.value = UiState.Loading
        _dashboardState.value = UiState.Loading
        viewModelScope.launch {
            try {
                val perms = repo.getMyPermissions()
                _permissionsState.value = UiState.Success(perms)
                // Only load the dashboard if the user is actually an admin.
                // The backend would have returned 403 otherwise — but the
                // local check avoids an unnecessary network round-trip.
                if (Roles.canAccessAdmin(perms.role)) {
                    try {
                        val dashboard = repo.getDashboard()
                        _dashboardState.value = UiState.Success(dashboard)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        _dashboardState.value = UiState.Error(e.message ?: "Could not load dashboard.")
                    }
                } else {
                    _dashboardState.value = UiState.Error(
                        "Your account does not have permission to access the admin panel."
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _permissionsState.value = UiState.Error(e.message ?: "Could not load permissions.")
                _dashboardState.value = UiState.Error(e.message ?: "Could not load permissions.")
            }
        }
    }

    /** Convenience: the set of permission keys for the current admin
     *  (empty if not yet loaded). */
    fun currentPermissions(): Set<String> {
        return ((permissionsState.value as? UiState.Success)?.data?.permissions ?: emptyList()).toSet()
    }

    /** Convenience: true if the current admin has the [key] permission. */
    fun hasPermission(key: String): Boolean {
        val perms = currentPermissions()
        val role = (permissionsState.value as? UiState.Success)?.data?.role
        return Roles.isSuperAdmin(role) || Permissions.hasPermission(perms, key)
    }
}
