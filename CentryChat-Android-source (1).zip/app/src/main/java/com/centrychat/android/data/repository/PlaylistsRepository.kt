package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.PlaylistDto
import com.centrychat.android.data.model.PlaylistItemsResponse
import com.centrychat.android.data.model.PlaylistsListResponse
import com.centrychat.android.data.model.safeApiCall

/**
 * Playlists repository — wraps `/api/v1/playlists/[endpoint]`.
 *
 * Ordered collections of ARTICLES ONLY (independent from Collections).
 * Limits: 100 playlists/user, 200 items/playlist (admin-configurable).
 * Public playlists get SSR + JSON-LD ItemList on the web.
 */
class PlaylistsRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** List the current user's playlists. */
    suspend fun getPlaylists(limit: Int = 50): PlaylistsListResponse =
        safeApiCall { api.getPlaylists(limit = limit) }

    /** Create a new playlist. */
    suspend fun createPlaylist(
        name: String,
        description: String? = null,
        visibility: String = "PRIVATE",
    ): PlaylistDto {
        val body = mapOf<String, String?>(
            "name" to name,
            "description" to description,
            "visibility" to visibility,
        )
        return safeApiCall { api.createPlaylist(body = body, origin = origin) }
    }

    /** Fetch a single playlist by ID. */
    suspend fun getPlaylist(id: String): PlaylistDto =
        safeApiCall { api.getPlaylist(id) }

    /** Delete a playlist. */
    suspend fun deletePlaylist(id: String): Boolean {
        safeApiCall { api.deletePlaylist(id = id, origin = origin) }
        return true
    }

    /** Fetch items (articles) in a playlist. */
    suspend fun getItems(id: String, limit: Int = 50): PlaylistItemsResponse =
        safeApiCall { api.getPlaylistItems(id = id, limit = limit) }

    /** Add an article to a playlist. */
    suspend fun addArticle(playlistId: String, articleId: String): Boolean {
        val body = mapOf<String, String?>("articleId" to articleId)
        safeApiCall { api.addPlaylistItem(id = playlistId, body = body, origin = origin) }
        return true
    }

    /** Remove an article from a playlist. */
    suspend fun removeArticle(playlistId: String, itemId: String): Boolean {
        safeApiCall { api.removePlaylistItem(id = playlistId, itemId = itemId, origin = origin) }
        return true
    }
}
