package com.centrychat.android.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * The navigation routes for the app.
 */
object Routes {

    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val FORGOT_PASSWORD = "forgot_password"
    const val RESET_PASSWORD = "reset_password?token={token}"
    const val RESET_PASSWORD_BASE = "reset_password"

    const val HOME = "home"
    const val SEARCH = "search"
    const val NOTIFICATIONS = "notifications"
    const val PROFILE = "profile"
    const val SETTINGS = "settings"

    const val POST_DETAIL = "post/{postId}"
    const val POST_DETAIL_BASE = "post"
    const val ARTICLE_DETAIL = "article/{articleId}"
    const val ARTICLE_DETAIL_BASE = "article"
    const val USER_PROFILE = "user/{username}"
    const val USER_PROFILE_BASE = "user"
    const val FOLLOWERS = "followers/{username}"
    const val FOLLOWERS_BASE = "followers"
    const val FOLLOWING = "following/{username}"
    const val FOLLOWING_BASE = "following"
    const val EDIT_PROFILE = "edit_profile"
    const val COMMENTS = "comments/{postId}"
    const val COMMENTS_BASE = "comments"

    // ── New routes (feature-parity expansion) ─────────────────────────
    const val ADMIN_DASHBOARD = "admin_dashboard"
    const val ADMIN_SECTION = "admin/{section}"
    const val ADMIN_SECTION_BASE = "admin"
    const val TOPICS = "topics"
    const val TOPIC_DETAIL = "topic/{slug}"
    const val TOPIC_DETAIL_BASE = "topic"
    const val COLLECTIONS = "collections"
    const val COLLECTION_DETAIL = "collection/{id}"
    const val COLLECTION_DETAIL_BASE = "collection"
    const val PLAYLISTS = "playlists"
    const val PLAYLIST_DETAIL = "playlist/{id}"
    const val PLAYLIST_DETAIL_BASE = "playlist"
    const val POST_COMPOSER = "post_composer"
    const val ARTICLE_EDITOR = "article_editor"
    const val ARTICLE_EDITOR_EDIT = "article_editor/{id}"
    const val ARTICLE_EDITOR_BASE = "article_editor"
    const val SITE_PAGE = "site_page/{slug}"
    const val SITE_PAGE_BASE = "site_page"
    const val CONVERSATIONS = "conversations"
    const val CONVERSATION_DETAIL = "conversation/{conversationId}/{username}"
    const val CONVERSATION_DETAIL_BASE = "conversation"

    fun postDetail(postId: String) = "$POST_DETAIL_BASE/$postId"
    fun articleDetail(articleId: String) = "$ARTICLE_DETAIL_BASE/$articleId"
    fun userProfile(username: String) = "$USER_PROFILE_BASE/$username"
    fun followers(username: String) = "$FOLLOWERS_BASE/$username"
    fun following(username: String) = "$FOLLOWING_BASE/$username"
    fun resetPassword(token: String) = "$RESET_PASSWORD_BASE?token=$token"
    fun comments(postId: String) = "$COMMENTS_BASE/$postId"
    fun adminSection(section: String) = "$ADMIN_SECTION_BASE/$section"
    fun topicDetail(slug: String) = "$TOPIC_DETAIL_BASE/$slug"
    fun collectionDetail(id: String) = "$COLLECTION_DETAIL_BASE/$id"
    fun playlistDetail(id: String) = "$PLAYLIST_DETAIL_BASE/$id"
    fun articleEditorEdit(id: String) = "$ARTICLE_EDITOR_BASE/$id"
    fun sitePage(slug: String) = "$SITE_PAGE_BASE/$slug"
    fun conversationDetail(conversationId: String, username: String) =
        "$CONVERSATION_DETAIL_BASE/$conversationId/$username"
}

/**
 * The bottom-nav destinations.
 */
enum class BottomNavDestination(
    val route: String,
    val labelRes: Int,
    val icon: ImageVector,
    val selectedIcon: ImageVector,
    /** If true, this destination is only rendered when the user has admin role. */
    val adminOnly: Boolean = false,
) {
    HOME(
        route = Routes.HOME,
        labelRes = com.centrychat.android.R.string.nav_home,
        icon = Icons.AutoMirrored.Filled.List,
        selectedIcon = Icons.AutoMirrored.Filled.List,
    ),
    SEARCH(
        route = Routes.SEARCH,
        labelRes = com.centrychat.android.R.string.nav_search,
        icon = Icons.Filled.Search,
        selectedIcon = Icons.Filled.Search,
    ),
    NOTIFICATIONS(
        route = Routes.NOTIFICATIONS,
        labelRes = com.centrychat.android.R.string.nav_notifications,
        icon = Icons.Filled.Notifications,
        selectedIcon = Icons.Filled.Notifications,
    ),
    PROFILE(
        route = Routes.PROFILE,
        labelRes = com.centrychat.android.R.string.nav_profile,
        icon = Icons.Filled.Person,
        selectedIcon = Icons.Filled.Person,
    ),
    MESSAGES(
        route = Routes.CONVERSATIONS,
        labelRes = com.centrychat.android.R.string.nav_messages,
        icon = Icons.Filled.Email,
        selectedIcon = Icons.Filled.Email,
    ),
    ADMIN(
        route = Routes.ADMIN_DASHBOARD,
        labelRes = com.centrychat.android.R.string.nav_admin,
        icon = Icons.Filled.AdminPanelSettings,
        selectedIcon = Icons.Filled.AdminPanelSettings,
        adminOnly = true,
    ),
}
