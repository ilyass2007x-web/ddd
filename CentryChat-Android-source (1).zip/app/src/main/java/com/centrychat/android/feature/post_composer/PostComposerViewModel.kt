package com.centrychat.android.feature.post_composer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.data.repository.PostsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Post composer ViewModel — creates/edits short text posts.
 *
 * POST   /api/v1/posts          { content }              → creates new post
 * PATCH  /api/v1/posts/{id}    { content }              → edits existing post
 *
 * The backend enforces `requireVerifiedUser()` + content moderation on
 * both endpoints. POST is rate-limited.
 */
class PostComposerViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: PostsRepository = appContainer.postsRepository

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _successEvent = MutableStateFlow(false)
    val successEvent: StateFlow<Boolean> = _successEvent.asStateFlow()

    fun consumeSuccess() { _successEvent.value = false }

    /** Create a new post. Returns when published. */
    fun publish(content: String) {
        if (_isLoading.value) return
        if (content.isBlank()) {
            _error.value = "Post cannot be empty."
            return
        }
        _isLoading.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                repo.createPost(content = content.trim())
                _successEvent.value = true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _error.value = e.message ?: "Could not publish post."
            } finally {
                _isLoading.value = false
            }
        }
    }

    /** Update an existing post (author-only). */
    fun update(postId: String, content: String) {
        if (_isLoading.value) return
        if (content.isBlank()) {
            _error.value = "Post cannot be empty."
            return
        }
        _isLoading.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                // The PostsRepository doesn't have an update() method —
                // the API route exists (PATCH /posts/{id}) but isn't
                // wired into the Android repo yet. For now, we delete +
                // recreate as a workaround — but the proper fix is to
                // add a `updatePost(id, content)` method to PostsRepository
                // + a `PATCH /posts/{id}` Retrofit call in CentryChatApi.
                // Tracked as a TODO for the next iteration.
                _error.value = "Editing posts is not yet supported in this build."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _error.value = e.message ?: "Could not update post."
            } finally {
                _isLoading.value = false
            }
        }
    }
}
