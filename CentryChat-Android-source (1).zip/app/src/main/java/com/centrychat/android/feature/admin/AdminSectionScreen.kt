package com.centrychat.android.feature.admin

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.centrychat.android.CentryChatApp
import com.centrychat.android.R
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.AdminAuditListResponse
import com.centrychat.android.data.model.AdminContentListResponse
import com.centrychat.android.data.model.AdminFeaturesResponse
import com.centrychat.android.data.model.AdminSecurityResponse
import com.centrychat.android.data.model.AdminSettingsResponse
import com.centrychat.android.data.model.AdminSystemResponse
import com.centrychat.android.data.model.AdminUsersListResponse
import com.centrychat.android.data.model.AdMobAppDto
import com.centrychat.android.data.model.AdMobSettingsDto
import com.centrychat.android.data.model.AdMobSettingsUpdateBody
import com.centrychat.android.data.model.AdMobAppUpdateBody
import com.centrychat.android.data.model.AdUnitCreateBody
import com.centrychat.android.data.model.AdUnitDto
import com.centrychat.android.data.model.AdUnitUpdateBody
import com.centrychat.android.data.model.AdUnitsListResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Admin section screen — dispatches to the right content based on the
 * section route argument. Each section fetches its data via the
 * AdminRepository (which calls /api/v1/admin/[section] endpoints — server-side
 * enforced via `requireAdmin()` + `requirePermission()`). Non-admins
 * receive HTTP 403 + a structured error message via `safeApiCall`.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminSectionScreen(
    section: String,
    onBack: () -> Unit,
) {
    val titleRes = when (section) {
        "users" -> R.string.admin_section_users
        "content" -> R.string.admin_section_content
        "settings" -> R.string.admin_section_settings
        "features" -> R.string.admin_section_features
        "audit" -> R.string.admin_section_audit
        "system" -> R.string.admin_section_system
        "security" -> R.string.admin_section_security
        "broadcast" -> R.string.admin_section_broadcast
        "adunits" -> R.string.admin_section_adunits
        else -> R.string.admin_section_dashboard
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(titleRes)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        androidx.compose.foundation.layout.Box(
            modifier = Modifier
                .then(androidx.compose.ui.Modifier)
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
        ) {
            when (section) {
                "users" -> AdminUsersSection()
                "content" -> AdminContentSection()
                "settings" -> AdminSettingsSection()
                "features" -> AdminFeaturesSection()
                "audit" -> AdminAuditSection()
                "system" -> AdminSystemSection()
                "security" -> AdminSecuritySection()
                "broadcast" -> AdminBroadcastSection()
                "adunits" -> AdminAdUnitsSection()
                else -> Text("Section not yet implemented on mobile.")
            }
        }
    }
}

@Composable
private fun appContainer(): com.centrychat.android.core.AppContainer? {
    val ctx = LocalContext.current
    return (ctx.applicationContext as? CentryChatApp)?.appContainer
}

@Composable
private fun AdminUsersSection() {
    val repo = appContainer()?.adminRepository ?: return
    var state by remember { mutableStateOf<UiState<AdminUsersListResponse>>(UiState.Loading) }
    val scope = remember { CoroutineScope(SupervisorJob() + Dispatchers.IO) }
    LaunchedEffect(Unit) {
        scope.launch {
            try { state = UiState.Success(repo.getUsers()) }
            catch (e: Exception) { state = UiState.Error(e.message ?: "Could not load users.") }
        }
    }
    when (val s = state) {
        is UiState.Loading -> Text("Loading users…")
        is UiState.Error -> Text(s.message, color = MaterialTheme.colorScheme.error)
        is UiState.Success -> Column {
            Text("Total: ${s.data.total}", style = MaterialTheme.typography.titleMedium)
            s.data.users.forEach { u ->
                Text("${u.fullName} (@${u.username}) — ${u.role} / ${u.status}")
            }
        }
        is UiState.Empty -> Text("No users.")
    }
}

@Composable
private fun AdminContentSection() {
    val repo = appContainer()?.adminRepository ?: return
    var state by remember { mutableStateOf<UiState<AdminContentListResponse>>(UiState.Loading) }
    val scope = remember { CoroutineScope(SupervisorJob() + Dispatchers.IO) }
    LaunchedEffect(Unit) {
        scope.launch {
            try { state = UiState.Success(repo.getContent()) }
            catch (e: Exception) { state = UiState.Error(e.message ?: "Could not load content.") }
        }
    }
    when (val s = state) {
        is UiState.Loading -> Text("Loading content…")
        is UiState.Error -> Text(s.message, color = MaterialTheme.colorScheme.error)
        is UiState.Success -> Column {
            Text("Total: ${s.data.total}", style = MaterialTheme.typography.titleMedium)
            s.data.items.forEach { c ->
                Text("[${c.type}] ${c.title ?: c.content?.take(40)} — ${c.status}")
            }
        }
        is UiState.Empty -> Text("No content.")
    }
}

@Composable
private fun AdminSettingsSection() {
    val repo = appContainer()?.adminRepository ?: return
    var state by remember { mutableStateOf<UiState<AdminSettingsResponse>>(UiState.Loading) }
    val scope = remember { CoroutineScope(SupervisorJob() + Dispatchers.IO) }
    LaunchedEffect(Unit) {
        scope.launch {
            try { state = UiState.Success(repo.getSettings()) }
            catch (e: Exception) { state = UiState.Error(e.message ?: "Could not load settings.") }
        }
    }
    when (val s = state) {
        is UiState.Loading -> Text("Loading settings…")
        is UiState.Error -> Text(s.message, color = MaterialTheme.colorScheme.error)
        is UiState.Success -> Column {
            Text("${s.data.settings.size} platform settings:", style = MaterialTheme.typography.titleMedium)
            s.data.settings.take(50).forEach { e ->
                Text("${e.key} = ${e.value ?: "(empty)"}  [${e.type}]")
            }
        }
        is UiState.Empty -> Text("No settings.")
    }
}

@Composable
private fun AdminFeaturesSection() {
    val repo = appContainer()?.adminRepository ?: return
    var state by remember { mutableStateOf<UiState<AdminFeaturesResponse>>(UiState.Loading) }
    val scope = remember { CoroutineScope(SupervisorJob() + Dispatchers.IO) }
    LaunchedEffect(Unit) {
        scope.launch {
            try { state = UiState.Success(repo.getFeatures()) }
            catch (e: Exception) { state = UiState.Error(e.message ?: "Could not load features.") }
        }
    }
    when (val s = state) {
        is UiState.Loading -> Text("Loading features…")
        is UiState.Error -> Text(s.message, color = MaterialTheme.colorScheme.error)
        is UiState.Success -> Column {
            s.data.features.forEach { f -> Text("[${if (f.enabled) "x" else " "}] ${f.key}") }
        }
        is UiState.Empty -> Text("No features.")
    }
}

@Composable
private fun AdminAuditSection() {
    val repo = appContainer()?.adminRepository ?: return
    var state by remember { mutableStateOf<UiState<AdminAuditListResponse>>(UiState.Loading) }
    val scope = remember { CoroutineScope(SupervisorJob() + Dispatchers.IO) }
    LaunchedEffect(Unit) {
        scope.launch {
            try { state = UiState.Success(repo.getAudit()) }
            catch (e: Exception) { state = UiState.Error(e.message ?: "Could not load audit log.") }
        }
    }
    when (val s = state) {
        is UiState.Loading -> Text("Loading audit log…")
        is UiState.Error -> Text(s.message, color = MaterialTheme.colorScheme.error)
        is UiState.Success -> Column {
            s.data.logs.take(50).forEach { l ->
                Text("${l.createdAt}  ${l.action}  (${l.adminName ?: l.adminId ?: "—"})")
            }
        }
        is UiState.Empty -> Text("No audit log entries.")
    }
}

@Composable
private fun AdminSystemSection() {
    val repo = appContainer()?.adminRepository ?: return
    var state by remember { mutableStateOf<UiState<AdminSystemResponse>>(UiState.Loading) }
    val scope = remember { CoroutineScope(SupervisorJob() + Dispatchers.IO) }
    LaunchedEffect(Unit) {
        scope.launch {
            try { state = UiState.Success(repo.getSystem()) }
            catch (e: Exception) { state = UiState.Error(e.message ?: "Could not load system info.") }
        }
    }
    when (val s = state) {
        is UiState.Loading -> Text("Loading system info…")
        is UiState.Error -> Text(s.message, color = MaterialTheme.colorScheme.error)
        is UiState.Success -> Column {
            s.data.node?.let { Text("Node: $it") }
            Text("Uptime: ${s.data.uptime} seconds")
            s.data.memory?.let { m ->
                Text("Memory (RSS): ${m.rss} bytes")
                Text("Memory (heap used): ${m.heapUsed} / ${m.heapTotal} bytes")
            }
            s.data.providers?.let { p ->
                Text("Database provider: ${p.database}")
                Text("Email provider: ${p.email}")
                Text("Cache provider: ${p.cache}")
                Text("Realtime provider: ${p.realtime}")
            }
        }
        is UiState.Empty -> {}
    }
}

@Composable
private fun AdminSecuritySection() {
    val repo = appContainer()?.adminRepository ?: return
    var state by remember { mutableStateOf<UiState<AdminSecurityResponse>>(UiState.Loading) }
    val scope = remember { CoroutineScope(SupervisorJob() + Dispatchers.IO) }
    LaunchedEffect(Unit) {
        scope.launch {
            try { state = UiState.Success(repo.getSecurity()) }
            catch (e: Exception) { state = UiState.Error(e.message ?: "Could not load security info.") }
        }
    }
    when (val s = state) {
        is UiState.Loading -> Text("Loading security info…")
        is UiState.Error -> Text(s.message, color = MaterialTheme.colorScheme.error)
        is UiState.Success -> Column {
            Text("Security headers:", style = MaterialTheme.typography.titleSmall)
            s.data.headers.forEach { (k, v) -> Text("  $k: $v") }
            Text("Rate limits:", style = MaterialTheme.typography.titleSmall)
            s.data.rateLimits.forEach { (k, v) -> Text("  $k: $v") }
            s.data.audit?.let { a ->
                Text("Audit events (total): ${a.totalEvents}")
                Text("Audit events (last 24h): ${a.last24h}")
            }
        }
        is UiState.Empty -> {}
    }
}

@Composable
private fun AdminBroadcastSection() {
    val repo = appContainer()?.adminRepository ?: return
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var audience by remember { mutableStateOf("all") }
    var status by remember { mutableStateOf<String?>(null) }
    val scope = remember { CoroutineScope(SupervisorJob() + Dispatchers.IO) }
    Column {
        Text("Broadcast a notification to all users. Use with care.",
            style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(
            value = title, onValueChange = { title = it },
            label = { Text("Title") }, modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = message, onValueChange = { message = it },
            label = { Text("Message") }, modifier = Modifier.fillMaxWidth(),
        )
        Button(onClick = {
            scope.launch {
                try {
                    repo.broadcastNotification(title, message, audience)
                    status = "Notification sent."
                } catch (e: Exception) { status = e.message }
            }
        }, enabled = title.isNotBlank() && message.isNotBlank()) {
            Text("Send broadcast")
        }
        status?.let { Text(it, color = MaterialTheme.colorScheme.secondary) }
    }
}

/**
 * Admin: Publishing & Ad Units section.
 *
 * Replaces the web's "AdMob" section in the Android admin dashboard.
 *
 * Three sub-sections (vertically stacked, no tabs — keeps the mobile UX simple):
 *   1. Global settings (enabled toggle, environment, min versions, config version)
 *   2. AdMob apps (Android + iOS rows — App ID, package name, enable toggle)
 *   3. Ad units (list with toggle active/inactive, basic create form)
 *
 * The same backend `/api/v1/admin/admob/` routes serve both the web admin
 * and this Android section. Edits sync both ways instantly (cache invalidation
 * is server-side). Permission gating is server-side: ADS_VIEW to read,
 * ADS_MANAGE to write — the backend returns HTTP 403 if missing.
 *
 * Source of truth: AdMobAdUnit + AdMobApp tables + admob. settings keys.
 */
@Composable
private fun AdminAdUnitsSection() {
    val repo = appContainer()?.adminRepository ?: return
    val scope = remember { CoroutineScope(SupervisorJob() + Dispatchers.IO) }

    // ── State ──
    var settingsState by remember { mutableStateOf<UiState<AdMobSettingsDto>>(UiState.Loading) }
    var appsState by remember { mutableStateOf<UiState<List<AdMobAppDto>>>(UiState.Loading) }
    var unitsState by remember { mutableStateOf<UiState<List<AdUnitDto>>>(UiState.Loading) }
    var actionStatus by remember { mutableStateOf<String?>(null) }

    // ── Loaders ──
    fun loadSettings() {
        scope.launch {
            try { settingsState = UiState.Success(repo.getAdMobSettings().settings) }
            catch (e: Exception) { settingsState = UiState.Error(e.message ?: "Could not load settings.") }
        }
    }
    fun loadApps() {
        scope.launch {
            try { appsState = UiState.Success(repo.getAdMobApps().apps) }
            catch (e: Exception) { appsState = UiState.Error(e.message ?: "Could not load apps.") }
        }
    }
    fun loadUnits() {
        scope.launch {
            try { unitsState = UiState.Success(repo.getAdUnits().units) }
            catch (e: Exception) { unitsState = UiState.Error(e.message ?: "Could not load ad units.") }
        }
    }

    LaunchedEffect(Unit) {
        loadSettings(); loadApps(); loadUnits()
    }

    Column {
        // ── Header ──
        Text(
            "Mobile ad management — shared with the web admin.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        actionStatus?.let {
            Text(
                it,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(top = 4.dp),
            )
        }

        // ── 1. Global settings ──
        Text(
            "Global settings",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(top = 16.dp),
        )
        when (val s = settingsState) {
            is UiState.Loading -> Text("Loading settings…")
            is UiState.Error -> Text(s.message, color = MaterialTheme.colorScheme.error)
            is UiState.Success -> {
                val cfg = s.data
                Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Enabled: ${if (cfg.enabled) "yes" else "no"}")
                        Text("Environment: ${cfg.environment}")
                        Text("Android min version: ${cfg.androidMinVersion}")
                        Text("iOS min version: ${cfg.iosMinVersion}")
                        Text("Config version: ${cfg.configVersion}")
                        Row {
                            Button(
                                onClick = {
                                    scope.launch {
                                        try {
                                            repo.updateAdMobSettings(
                                                AdMobSettingsUpdateBody(enabled = !cfg.enabled)
                                            )
                                            actionStatus = "Toggled enabled."
                                            loadSettings()
                                        } catch (e: Exception) { actionStatus = e.message }
                                    }
                                },
                                modifier = Modifier.padding(end = 8.dp),
                            ) { Text(if (cfg.enabled) "Disable" else "Enable") }
                            Button(onClick = {
                                scope.launch {
                                    try {
                                        repo.updateAdMobSettings(
                                            AdMobSettingsUpdateBody(
                                                environment = if (cfg.environment == "production") "development" else "production"
                                            )
                                        )
                                        actionStatus = "Switched environment."
                                        loadSettings()
                                    } catch (e: Exception) { actionStatus = e.message }
                                }
                            }) { Text("Switch env") }
                        }
                    }
                }
            }
            is UiState.Empty -> Text("No settings.")
        }

        // ── 2. AdMob apps (Android + iOS) ──
        Text(
            "Applications",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(top = 16.dp),
        )
        when (val s = appsState) {
            is UiState.Loading -> Text("Loading apps…")
            is UiState.Error -> Text(s.message, color = MaterialTheme.colorScheme.error)
            is UiState.Success -> {
                if (s.data.isEmpty()) {
                    Text("No apps configured.")
                } else {
                    s.data.forEach { app -> AdMobAppRow(app, repo, scope) { loadApps(); actionStatus = it } }
                }
            }
            is UiState.Empty -> Text("No apps configured.")
        }

        // ── 3. Ad units ──
        Text(
            "Ad units",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(top = 16.dp),
        )
        when (val s = unitsState) {
            is UiState.Loading -> Text("Loading ad units…")
            is UiState.Error -> Text(s.message, color = MaterialTheme.colorScheme.error)
            is UiState.Success -> {
                if (s.data.isEmpty()) {
                    Text("No ad units yet.")
                } else {
                    s.data.forEach { unit ->
                        AdUnitRow(
                            unit = unit,
                            onToggle = {
                                scope.launch {
                                    try {
                                        repo.toggleAdUnitActive(unit.id, !unit.active)
                                        actionStatus = "Toggled ${unit.name}."
                                        loadUnits()
                                    } catch (e: Exception) { actionStatus = e.message }
                                }
                            },
                            onDelete = {
                                scope.launch {
                                    try {
                                        repo.deleteAdUnit(unit.id)
                                        actionStatus = "Deleted ${unit.name}."
                                        loadUnits()
                                    } catch (e: Exception) { actionStatus = e.message }
                                }
                            },
                        )
                    }
                }
            }
            is UiState.Empty -> Text("No ad units yet.")
        }

        // ── 4. Quick create form ──
        AdUnitCreateForm(
            onCreate = { body ->
                scope.launch {
                    try {
                        repo.createAdUnit(body)
                        actionStatus = "Created ad unit."
                        loadUnits()
                    } catch (e: Exception) { actionStatus = e.message }
                }
            },
        )
    }
}

@Composable
private fun AdMobAppRow(
    app: AdMobAppDto,
    repo: com.centrychat.android.data.repository.AdminRepository,
    scope: CoroutineScope,
    onResult: (String?) -> Unit,
) {
    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text("${app.platform} — ${app.appName}")
            Text("App ID: ${app.admobAppId}", style = MaterialTheme.typography.bodySmall)
            app.packageName?.let { Text("Package: $it", style = MaterialTheme.typography.bodySmall) }
            Text("Status: ${if (app.enabled) "enabled" else "disabled"}",
                style = MaterialTheme.typography.bodySmall)
            Button(onClick = {
                scope.launch {
                    try {
                        repo.updateAdMobApp(
                            AdMobAppUpdateBody(
                                platform = app.platform,
                                enabled = !app.enabled,
                            )
                        )
                        onResult("Toggled ${app.platform} app.")
                    } catch (e: Exception) { onResult(e.message) }
                }
            }) { Text(if (app.enabled) "Disable" else "Enable") }
        }
    }
}

@Composable
private fun AdUnitRow(
    unit: AdUnitDto,
    onToggle: () -> Unit,
    onDelete: () -> Unit,
) {
    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(12.dp)) {
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    unit.name,
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    if (unit.active) "● active" else "○ inactive",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (unit.active)
                        MaterialTheme.colorScheme.primary
                    else
                        MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Text("${unit.platform} · ${unit.format} · ${unit.placement}",
                style = MaterialTheme.typography.bodySmall)
            Text("Ad unit ID: ${unit.adUnitId}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            unit.description?.let {
                Text(it, style = MaterialTheme.typography.bodySmall)
            }
            Text("Priority: ${unit.priority} · Env: ${unit.environment}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(modifier = Modifier.padding(top = 4.dp)) {
                Button(onClick = onToggle, modifier = Modifier.padding(end = 8.dp)) {
                    Text(if (unit.active) "Disable" else "Enable")
                }
                Button(onClick = onDelete) { Text("Delete") }
            }
        }
    }
}

@Composable
private fun AdUnitCreateForm(onCreate: (AdUnitCreateBody) -> Unit) {
    var name by remember { mutableStateOf("") }
    var platform by remember { mutableStateOf("ANDROID") }
    var adUnitId by remember { mutableStateOf("") }
    var format by remember { mutableStateOf("BANNER") }
    var placement by remember { mutableStateOf("APP_FEED") }
    var description by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }

    Text(
        "Create new ad unit",
        style = MaterialTheme.typography.titleSmall,
        modifier = Modifier.padding(top = 16.dp),
    )
    Button(
        onClick = { expanded = !expanded },
        modifier = Modifier.padding(vertical = 4.dp),
    ) {
        Text(if (expanded) "Hide form" else "Show form")
    }
    if (expanded) {
        Column {
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("Name") },
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
            )
            OutlinedTextField(
                value = adUnitId, onValueChange = { adUnitId = it },
                label = { Text("Ad Unit ID (ca-app-pub-XXXXXXXXXXXXXXXX/ZZZZZZZZZZ)") },
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
            )
            OutlinedTextField(
                value = platform, onValueChange = { platform = it },
                label = { Text("Platform (ANDROID or IOS)") },
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
            )
            OutlinedTextField(
                value = format, onValueChange = { format = it },
                label = { Text("Format (BANNER/INTERSTITIAL/REWARDED/NATIVE/APP_OPEN)") },
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
            )
            OutlinedTextField(
                value = placement, onValueChange = { placement = it },
                label = { Text("Placement (APP_FEED, APP_ARTICLE_TOP, …)") },
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
            )
            OutlinedTextField(
                value = description, onValueChange = { description = it },
                label = { Text("Description (optional)") },
                modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
            )
            Button(
                onClick = {
                    onCreate(
                        AdUnitCreateBody(
                            name = name.trim(),
                            platform = platform.trim().uppercase(),
                            adUnitId = adUnitId.trim(),
                            format = format.trim().uppercase(),
                            placement = placement.trim().uppercase(),
                            description = description.trim().ifBlank { null },
                        )
                    )
                    name = ""; adUnitId = ""; description = ""
                },
                enabled = name.isNotBlank() && adUnitId.isNotBlank(),
                modifier = Modifier.padding(vertical = 4.dp),
            ) { Text("Create ad unit") }
        }
    }
}
