package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.core.network.PersistentCookieJar
import com.centrychat.android.core.storage.SecureSessionStore
import com.centrychat.android.data.model.ApiException
import com.centrychat.android.data.model.ApiResponse
import com.centrychat.android.data.model.ForgotPasswordRequest
import com.centrychat.android.data.model.LoginRequest
import com.centrychat.android.data.model.LoginResponse
import com.centrychat.android.data.model.RegisterRequest
import com.centrychat.android.data.model.ResetPasswordRequest
import com.centrychat.android.data.model.UserDto
import com.centrychat.android.data.model.dataOrThrow
import com.centrychat.android.data.model.dataOrNull
import com.centrychat.android.data.model.toApiException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Authentication + session repository.
 *
 * This is the ONLY repository that talks to the [SecureSessionStore] + the
 * [PersistentCookieJar]. The rest of the app authenticates implicitly via
 * the OkHttp cookie jar — when the user is logged in, the cookie is sent
 * automatically; when they're not, requests fail with HTTP 401.
 *
 * The repository exposes a [currentUser] StateFlow that the rest of the
 * app observes for the auth state. It's set on login/register + cleared on
 * logout/expired.
 */
class AuthRepository(
    private val api: CentryChatApi,
    private val sessionStore: SecureSessionStore,
    private val appScope: CoroutineScope,
) {
    private val _currentUser = MutableStateFlow<UserDto?>(null)
    val currentUser: StateFlow<UserDto?> = _currentUser.asStateFlow()

    /** The Origin header value — set on every state-changing request to
     *  satisfy the backend's CSRF check. */
    private val origin: String = BuildConfig.API_ORIGIN

    /** Login with email + password. Returns the logged-in user, or throws
     *  an exception with the server's error message.
     *
     *  ERROR HANDLING:
     *   - HTTP 200 + `{ok:true, data:{...}}` → success, returns the user.
     *   - HTTP 401 + `{ok:false, error:{message:"Invalid email or password"}}` → throws ApiException with that message.
     *   - HTTP 403 + `{ok:false, error:{message:"Request blocked by security policy."}}` (CSRF check failure) → throws ApiException.
     *   - HTTP 429 + `{ok:false, error:{message:"Too many requests..."}}` (rate-limited) → throws ApiException.
     *   - HTTP 404 (Netlify "Not Found" — would mean Base URL is wrong) → throws IOException with a clear hint.
     *   - Network failure (no internet, DNS failure, SSL handshake failure) → throws IOException with the original cause.
     *
     *  The previous version called `response.dataOrThrow()` directly, which let
     *  Retrofit throw `HttpException` for non-2xx responses — losing the server's
     *  error message + showing a generic "HTTP 401 ..." string to the user.
     */
    suspend fun login(email: String, password: String): UserDto {
        val response = try {
            api.login(
                body = LoginRequest(email = email.trim(), password = password),
                origin = origin,
            )
        } catch (e: retrofit2.HttpException) {
            // The server returned non-2xx. Extract the structured error
            // message from the response body if present, else fall back
            // to a hint based on the HTTP code.
            throw e.toApiException()
        } catch (e: java.io.IOException) {
            // Network-layer failure (no DNS, no route, SSL handshake, etc.).
            throw java.io.IOException(
                "Could not connect to the server. Check your internet connection and try again.",
                e,
            )
        }
        val data = response.dataOrThrow()
        // `data.user` is non-null on every successful login (the backend's
        // /api/v1/auth/login route always returns the full user object on
        // success — the anti-enumeration branch is ONLY in /register, not
        // /login). We defensively throw an ApiException if it's somehow null.
        val user = data.user
            ?: throw ApiException("Login succeeded but no user object was returned. Please try again.")
        _currentUser.value = user
        return user
    }

    /** Register a new account. Returns the newly created user (the backend
     *  auto-logs the user in + sets the session cookie).
     *
     *  Same error-handling logic as [login] — see the comment there for the
     *  full matrix of HTTP codes + how they map to user-facing messages.
     */
    suspend fun register(
        fullName: String,
        email: String,
        username: String,
        password: String,
        gender: String,
        dateOfBirth: String?,
        countryCode: String,
    ): UserDto {
        val response = try {
            api.register(
                body = RegisterRequest(
                    fullName = fullName.trim(),
                    email = email.trim(),
                    username = username.trim(),
                    password = password,
                    confirmPassword = password,
                    gender = gender,
                    dateOfBirth = dateOfBirth,
                    countryCode = countryCode,
                ),
                origin = origin,
            )
        } catch (e: retrofit2.HttpException) {
            throw e.toApiException()
        } catch (e: java.io.IOException) {
            throw java.io.IOException(
                "Could not connect to the server. Check your internet connection and try again.",
                e,
            )
        }
        val data = response.dataOrThrow()
        // ANTI-ENUMERATION HANDLING:
        // When the email is ALREADY registered, the backend returns
        // `{ "ok": true, "data": { "registered": true, "verificationRequired": true } }`
        // WITHOUT a `user` object + WITHOUT a `sessionId` — this is by design
        // (so an attacker can't tell whether the account was just created
        // or already existed). We surface this to the user as a soft error:
        //   "This email is already registered. Please log in."
        // The user is then expected to switch to the login screen.
        //
        // We do NOT silently log the user in (no session cookie was set,
        // because the backend's anti-enumeration branch doesn't create a
        // session). We do NOT navigate forward. We throw an ApiException
        // which the AuthViewModel catches + shows as the error message.
        val user = data.user
        if (user == null) {
            throw ApiException(
                "This email is already registered. Please log in with your existing account."
            )
        }
        // The register endpoint returns a REDUCED user object
        // `{ id, email, fullName, role }` — without `username`,
        // `avatarColor`, `gender`, `countryCode`, etc. The login + auth/me
        // endpoints return the full SafeUser. To avoid showing an empty
        // username in the UI right after register, we call /api/v1/auth/me
        // immediately. The cookie set by /register is already in the
        // OkHttp cookie jar (set synchronously when the response came back),
        // so this call will succeed.
        //
        // If /auth/me fails (transient network blip, rare), we fall back
        // to the reduced user from the register response — the UI will
        // show "@" with no handle for a moment, but the user IS logged in
        // (the cookie is set) and the next cold-start will fetch the full
        // user via the splash screen.
        val fullUser = try {
            fetchCurrentUser() ?: user
        } catch (_: Exception) {
            user
        }
        _currentUser.value = fullUser
        return fullUser
    }

    /** Send a password-reset email. Returns true on success (or when the
     *  email doesn't exist — the backend always returns success to prevent
     *  email enumeration). */
    suspend fun forgotPassword(email: String): Boolean {
        val response = api.forgotPassword(
            body = ForgotPasswordRequest(email = email.trim()),
            origin = origin,
        )
        // Anti-enumeration: the backend ALWAYS returns ok=true for forgot-
        // password (so an attacker can't tell which emails are registered).
        // We surface the actual error message if the backend reports one,
        // otherwise return true (treat as success).
        if (!response.ok) {
            throw java.io.IOException(response.error?.message ?: "Could not send reset email.")
        }
        return true
    }

    /** Reset the password using a token from the email link. */
    suspend fun resetPassword(token: String, newPassword: String): Boolean {
        val response = api.resetPassword(
            body = ResetPasswordRequest(
                token = token,
                password = newPassword,
                confirmPassword = newPassword,
            ),
            origin = origin,
        )
        if (!response.ok) {
            throw java.io.IOException(response.error?.message ?: "Could not reset password.")
        }
        return true
    }

    /** Resend the email-verification link (for users who skipped verification
     *  at signup). Best-effort — the backend may rate-limit. */
    suspend fun resendVerification(): Boolean {
        val response = api.resendVerification(origin = origin)
        return response.ok
    }

    /** Fetch the current user from `/api/v1/auth/me`. Returns null if the
     *  session has expired (HTTP 401). */
    suspend fun fetchCurrentUser(): UserDto? {
        return try {
            val response = api.getMe()
            // /api/v1/auth/me returns `{ "ok": true, "data": { "user": null } }`
            // when there is no session cookie — the `ok` flag is true (the
            // request itself succeeded) but the payload's `user` is null.
            // We treat `user == null` as "not logged in" and return null.
            val user = response.dataOrNull()?.user
            _currentUser.value = user
            user
        } catch (_: Exception) {
            null
        }
    }

    /** Log out — calls the backend (best-effort) then clears the local
     *  session store. */
    suspend fun logout() {
        try {
            api.logout(origin = origin)
        } catch (_: Exception) {
            // Network errors during logout are non-fatal — we still clear
            // the local session so the user is signed out on this device.
        }
        clearLocalSession()
    }

    /** Clears the local session without calling the backend. Called by the
     *  [com.centrychat.android.core.network.UnauthorizedInterceptor] when
     *  the backend returns HTTP 401. */
    fun clearLocalSession() {
        appScope.launch {
            sessionStore.clearSession()
        }
        _currentUser.value = null
    }

    /** True if a session cookie is currently stored locally. Note that the
     *  cookie may still be expired on the server side — use [fetchCurrentUser]
     *  to verify against the backend. */
    suspend fun hasLocalSession(): Boolean {
        return sessionStore.hasSession()
    }
}

// Note: the `toApiException()` extension on `retrofit2.HttpException` and the
// `parseErrorMessage()` helper are now PUBLIC in
// `com.centrychat.android.data.model.ApiResponse` (see `data/model/ApiResponse.kt`).
// They were moved out of this file so that ALL repositories (Profile, Articles,
// Posts, Feed, Notifications, Search) can share the same error-extraction logic
// via the `safeApiCall {}` helper — fixing the "HTTP 404 ..." generic-message
// bug app-wide, not just for the auth flow.
