package com.centrychat.android.core.util

/**
 * String helpers for the UI layer.
 *
 * The CentryChat backend stores short posts as raw text (max 500 chars).
 * For long-form display in feed cards, we truncate with an ellipsis. The
 * same helper is used for article excerpts, comment previews, etc.
 */
object TextUtils {

    /** Truncate to [maxChars] characters + append an ellipsis. Preserves word
     *  boundaries when possible (the truncation point is the last space
     *  before the limit). */
    fun truncate(text: String, maxChars: Int = 280): String {
        if (text.length <= maxChars) return text
        val cut = text.substring(0, maxChars)
        val lastSpace = cut.lastIndexOf(' ').coerceAtLeast(0)
        return "${cut.substring(0, lastSpace)}…"
    }

    /** Format a number with thousands separators (e.g. 12345 → "12.3K"). */
    fun compactCount(count: Long): String {
        return when {
            count < 1_000 -> count.toString()
            count < 1_000_000 -> {
                val v = count / 100.0
                "${(v / 10.0).let { String.format("%.1f", it).trimEnd('0').trimEnd('.') }}K"
            }
            count < 1_000_000_000 -> {
                val v = count / 100_000.0
                "${String.format("%.1f", v / 10.0).trimEnd('0').trimEnd('.')}M"
            }
            else -> "${count / 1_000_000_000}B"
        }
    }

    /** Strip @mentions and #hashtags from a string for preview display. */
    fun stripMarkup(text: String): String {
        return text
            .replace(Regex("@[A-Za-z0-9_]+"), "")
            .replace(Regex("#[A-Za-z0-9_]+"), "")
            .trim()
    }

    /** True if the string is a valid email (RFC 5322 simplified check). */
    fun isValidEmail(email: String): Boolean {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()
    }

    /** True if the string is a non-empty alphanumeric username (3-30 chars). */
    fun isValidUsername(username: String): Boolean {
        val pattern = Regex("^[A-Za-z0-9_]{3,30}$")
        return pattern.matches(username.trim())
    }
}
