package com.centrychat.android.feature.messaging

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Badge
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.centrychat.android.R
import com.centrychat.android.core.LocalAppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.ConversationDto
import com.centrychat.android.ui.components.ProfileIdentityRow

/**
 * Conversations list screen — shows the user's 1:1 direct conversations.
 *
 * Each row shows:
 *   [Avatar] Full Name ✓    (badge if verified)
 *            @username · last message preview
 *   (unread badge if unreadCount > 0)
 *
 * Tapping a row navigates to the conversation thread (ConversationDetailScreen).
 *
 * Polls every 15s for new messages (matches the web's MainNav unread-count
 * polling pattern). Real-time socket.io is tracked as a follow-up.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationsScreen(
    onConversationClick: (conversationId: String, otherUsername: String) -> Unit,
    onBack: () -> Unit,
) {
    val appContainer = LocalAppContainer.current
    val viewModel = remember { ConversationsViewModel(appContainer) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { viewModel.load() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.messages_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (val s = state) {
                is UiState.Loading -> Row(
                    modifier = Modifier.fillMaxWidth().padding(24.dp),
                    horizontalArrangement = Arrangement.Center,
                ) { CircularProgressIndicator() }
                is UiState.Error -> Text(
                    s.message,
                    modifier = Modifier.padding(24.dp),
                    color = MaterialTheme.colorScheme.error,
                )
                is UiState.Empty -> Text(
                    stringResource(R.string.messages_empty),
                    modifier = Modifier.padding(24.dp),
                )
                is UiState.Success -> LazyColumn(Modifier.fillMaxSize()) {
                    items(s.data) { conv ->
                        ConversationRow(conv, onClick = {
                            val otherUsername = conv.participant?.username
                                ?: conv.participants.firstOrNull()?.username.orEmpty()
                            onConversationClick(conv.id, otherUsername)
                        })
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConversationRow(conv: ConversationDto, onClick: () -> Unit) {
    val participant = conv.participant ?: conv.participants.firstOrNull()
    if (participant == null) {
        Text("[Unknown conversation]", modifier = Modifier.padding(16.dp))
        return
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        ProfileIdentityRow(
            fullName = participant.fullName,
            username = participant.username,
            avatarColor = participant.avatarColor,
            avatarUrl = participant.avatarUrl,
            isVerified = participant.isVerified,
            onClick = onClick,
            avatarSize = 48.dp,
            showUsername = false,
            compact = true,
        )
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            conv.lastMessage?.let { msg ->
                Text(
                    text = msg.content.take(40),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            if (conv.unreadCount > 0) {
                Badge { Text(conv.unreadCount.toString()) }
            }
        }
    }
}
