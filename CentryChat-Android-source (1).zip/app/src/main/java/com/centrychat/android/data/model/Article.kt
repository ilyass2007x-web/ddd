package com.centrychat.android.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Article DTOs.
 *
 * Mirror the shapes returned by `src/app/api/v1/articles/route.ts`
 * (list endpoint) and `src/app/api/v1/articles/[id]/route.ts` (detail).
 */

@Serializable
data class ArticleCardDto(
    val id: String,
    val title: String,
    val excerpt: String? = null,
    @SerialName("coverImage") val coverImage: String? = null,
    @SerialName("videoUrl") val videoUrl: String? = null,
    @SerialName("imageZoom") val imageZoom: Float? = null,
    @SerialName("imagePositionX") val imagePositionX: Float? = null,
    @SerialName("imagePositionY") val imagePositionY: Float? = null,
    @SerialName("publishedAt") val publishedAt: String? = null,
    @SerialName("readingTime") val readingTime: Int? = null,
    val author: AuthorDto,
    @SerialName("likeCount") val likeCount: Long = 0,
    @SerialName("commentCount") val commentCount: Long = 0,
    @SerialName("viewCount") val viewCount: Long = 0,
    @SerialName("shareCount") val shareCount: Long = 0,
    @SerialName("isLiked") val isLiked: Boolean = false,
)

@Serializable
data class ArticleDetailDto(
    val id: String,
    val title: String,
    val content: String,
    val excerpt: String? = null,
    @SerialName("coverImage") val coverImage: String? = null,
    @SerialName("videoUrl") val videoUrl: String? = null,
    @SerialName("imageZoom") val imageZoom: Float? = null,
    @SerialName("imagePositionX") val imagePositionX: Float? = null,
    @SerialName("imagePositionY") val imagePositionY: Float? = null,
    @SerialName("showCoverInArticle") val showCoverInArticle: Boolean = true,
    @SerialName("adsEnabled") val adsEnabled: Boolean = true,
    val status: String = "PUBLISHED",
    @SerialName("moderationStatus") val moderationStatus: String = "APPROVED",
    @SerialName("publishedAt") val publishedAt: String? = null,
    @SerialName("readingTime") val readingTime: Int? = null,
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("updatedAt") val updatedAt: String = "",
    val author: AuthorDto,
    @SerialName("likeCount") val likeCount: Long = 0,
    @SerialName("commentCount") val commentCount: Long = 0,
    @SerialName("viewCount") val viewCount: Long = 0,
    @SerialName("shareCount") val shareCount: Long = 0,
    @SerialName("isLiked") val isLiked: Boolean = false,
    @SerialName("topicIds") val topicIds: List<String> = emptyList(),
)

@Serializable
data class ArticleListResponse(
    val articles: List<ArticleCardDto>,
    @SerialName("nextCursor") val nextCursor: String? = null,
)

/**
 * Response wrapper for `GET /api/v1/articles/{id}` (article detail).
 *
 * The backend returns:
 *   `{ "ok": true, "data": { "article": { id, title, content, author, ... } } }`
 *
 * The inner `article` object IS the [ArticleDetailDto]. Without this
 * wrapper, kotlinx-serialization tried to deserialize `data` directly into
 * `ArticleDetailDto` and crashed with:
 *   `Fields [id, title, content, author] are required for type with serial
 *    name 'ArticleDetailDto', but they were missing at path: $.data`
 * because `data` actually contains an `article` field, not the article's
 * fields directly.
 *
 * Captured via curl on 2026-09-28 against the production backend:
 *   curl https://sentrychat.netlify.app/api/v1/articles/cmsmg2gql0010ffvw5atpn54k
 *   → {"ok":true,"data":{"article":{"id":"...","title":"...","content":"<h1>...",
 *      "author":{...},"_count":{"likes":0,...},"likeCount":0,...}}}
 *
 * The `_count` field is silently dropped because `ignoreUnknownKeys = true`
 * in RetrofitFactory — the counts are duplicated as `likeCount`,
 * `commentCount`, `viewCount`, `shareCount` at the top level of the
 * article object (which ARE in [ArticleDetailDto]).
 */
@Serializable
data class ArticleDetailResponse(
    val article: ArticleDetailDto,
)
