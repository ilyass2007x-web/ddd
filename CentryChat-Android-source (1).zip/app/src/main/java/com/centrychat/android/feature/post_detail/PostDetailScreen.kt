package com.centrychat.android.feature.post_detail

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.centrychat.android.R
import com.centrychat.android.core.util.TextUtils
import com.centrychat.android.core.util.TimeFormatter
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.CommentDto
import com.centrychat.android.data.model.PostDto
import com.centrychat.android.rememberPostDetailViewModel
import com.centrychat.android.ui.components.CentryChatAvatar
import com.centrychat.android.ui.components.EmptyState
import com.centrychat.android.ui.components.ErrorState
import com.centrychat.android.ui.components.VerifiedBadge

/**
 * The post-detail screen — shows a single post + its comment thread.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostDetailScreen(
    postId: String,
    onBack: () -> Unit,
    onUserClick: (String) -> Unit,
) {
    val viewModel = rememberPostDetailViewModel()
    val postState by viewModel.postState.collectAsStateWithLifecycle()
    val commentsState by viewModel.commentsState.collectAsStateWithLifecycle()
    val isSending by viewModel.isSendingComment.collectAsStateWithLifecycle()
    val replyTarget by viewModel.replyTarget.collectAsStateWithLifecycle()

    LaunchedEffect(postId) {
        viewModel.loadPost(postId)
        viewModel.loadComments(postId)
    }

    var commentText by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.post_action_comment)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.cd_back_button),
                        )
                    }
                },
            )
        },
        bottomBar = {
            CommentInputBar(
                text = commentText,
                onTextChange = { commentText = it },
                isSending = isSending,
                replyTarget = replyTarget,
                onSend = {
                    viewModel.sendComment(
                        postId = postId,
                        content = commentText,
                        parentCommentId = replyTarget?.id,
                    )
                    commentText = ""
                },
                onCancelReply = { viewModel.setReplyTarget(null) },
            )
        },
    ) { padding ->
        Box(modifier = Modifier
            .fillMaxSize()
            .padding(padding)) {
            when (val state = postState) {
                UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                is UiState.Error -> ErrorState(message = state.message, onRetry = { viewModel.loadPost(postId) })
                is UiState.Empty -> EmptyState(message = "Post not found.")
                is UiState.Success -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        item {
                            PostHeader(
                                post = state.data,
                                onUserClick = onUserClick,
                                onLike = { viewModel.toggleLike(postId) },
                            )
                        }
                        item {
                            Text(
                                text = stringResource(R.string.comments_title),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            )
                        }
                        when (val cState = commentsState) {
                            UiState.Loading -> item {
                                Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator()
                                }
                            }
                            is UiState.Error -> item {
                                ErrorState(message = cState.message, onRetry = { viewModel.loadComments(postId) })
                            }
                            UiState.Empty -> item {
                                EmptyState(message = stringResource(R.string.comments_empty))
                            }
                            is UiState.Success -> {
                                items(cState.data) { comment ->
                                    CommentRow(
                                        comment = comment,
                                        onUserClick = onUserClick,
                                        onLike = { viewModel.toggleCommentLike(comment.id) },
                                        onReply = { viewModel.setReplyTarget(comment) },
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PostHeader(
    post: PostDto,
    onUserClick: (String) -> Unit,
    onLike: () -> Unit,
) {
    Column(Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CentryChatAvatar(
                fullName = post.author.fullName,
                avatarColor = post.author.avatarColor,
                avatarUrl = post.author.avatarUrl,
                onClick = { onUserClick(post.author.username) },
                size = 44.dp,
            )
            Spacer(Modifier.size(8.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = post.author.fullName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                    )
                    if (post.author.isVerified) {
                        Spacer(Modifier.size(4.dp))
                        VerifiedBadge()
                    }
                }
                Text(
                    text = "@${post.author.username} · ${TimeFormatter.relative(post.createdAt)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(text = post.content, style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
        ) {
            EngagementButton(
                icon = if (post.isLiked) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                count = post.likeCount,
                active = post.isLiked,
                onClick = onLike,
            )
            EngagementButton(
                icon = Icons.Filled.ChatBubbleOutline,
                count = post.commentCount,
            )
            EngagementButton(
                icon = Icons.Filled.Share,
                count = post.shareCount,
            )
        }
    }
}

@Composable
private fun EngagementButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    count: Long,
    active: Boolean = false,
    onClick: () -> Unit = {},
) {
    IconButton(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.size(4.dp))
            Text(
                text = TextUtils.compactCount(count),
                style = MaterialTheme.typography.bodySmall,
                color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun CommentRow(
    comment: CommentDto,
    onUserClick: (String) -> Unit,
    onLike: () -> Unit,
    onReply: () -> Unit,
) {
    Column(Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CentryChatAvatar(
                fullName = comment.author.fullName,
                avatarColor = comment.author.avatarColor,
                avatarUrl = comment.author.avatarUrl,
                onClick = { onUserClick(comment.author.username) },
                size = 32.dp,
            )
            Spacer(Modifier.size(8.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = comment.author.fullName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                    )
                    if (comment.author.isVerified) {
                        Spacer(Modifier.size(4.dp))
                        VerifiedBadge()
                    }
                    Spacer(Modifier.size(8.dp))
                    Text(
                        text = "· ${TimeFormatter.relative(comment.createdAt)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = comment.content,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(start = 40.dp),
        )
        Spacer(Modifier.height(4.dp))
        Row(
            modifier = Modifier.padding(start = 40.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            TextButton(
                text = if (comment.isLiked) "Liked" else "Like",
                count = comment.likeCount,
                onClick = onLike,
                active = comment.isLiked,
            )
            TextButton(
                text = "Reply",
                count = null,
                onClick = onReply,
            )
        }
        if (comment.replies.isNotEmpty()) {
            Column(modifier = Modifier
                .padding(start = 40.dp, top = 8.dp)) {
                comment.replies.forEach { reply ->
                    CommentRow(
                        comment = reply,
                        onUserClick = onUserClick,
                        onLike = onLike,
                        onReply = onReply,
                    )
                }
            }
        }
    }
}

@Composable
private fun TextButton(text: String, count: Long?, onClick: () -> Unit, active: Boolean = false) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = if (count != null) "$text · ${TextUtils.compactCount(count)}" else text,
            style = MaterialTheme.typography.labelMedium,
            color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun CommentInputBar(
    text: String,
    onTextChange: (String) -> Unit,
    isSending: Boolean,
    replyTarget: CommentDto?,
    onSend: () -> Unit,
    onCancelReply: () -> Unit,
) {
    Column(Modifier
        .fillMaxWidth()
        .padding(8.dp)) {
        if (replyTarget != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = stringResource(R.string.comments_reply_to, "@${replyTarget.author.username}"),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = onCancelReply) {
                    Icon(Icons.Filled.Share, contentDescription = "Cancel reply")
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text,
                onValueChange = onTextChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text(stringResource(R.string.comments_input_placeholder)) },
                singleLine = false,
                maxLines = 4,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                shape = RoundedCornerShape(24.dp),
            )
            Spacer(Modifier.size(8.dp))
            IconButton(
                onClick = onSend,
                enabled = text.isNotBlank() && !isSending,
            ) {
                if (isSending) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = stringResource(R.string.cd_send_comment),
                        tint = MaterialTheme.colorScheme.primary,
                    )
                }
            }
        }
    }
}
