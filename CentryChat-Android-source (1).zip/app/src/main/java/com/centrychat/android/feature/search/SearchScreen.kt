package com.centrychat.android.feature.search

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.centrychat.android.R
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.ArticleCardDto
import com.centrychat.android.data.model.PostDto
import com.centrychat.android.data.model.UserProfileSummary
import com.centrychat.android.feature.feed.PostSearchRow
import com.centrychat.android.rememberSearchViewModel
import com.centrychat.android.ui.components.EmptyState
import com.centrychat.android.ui.components.ErrorState
import com.centrychat.android.ui.components.UserRow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    contentPadding: PaddingValues,
    onUserClick: (String) -> Unit,
    onPostClick: (String) -> Unit,
    onArticleClick: (String) -> Unit,
) {
    val viewModel = rememberSearchViewModel()
    val query by viewModel.query.collectAsStateWithLifecycle()
    val state by viewModel.state.collectAsStateWithLifecycle()

    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = viewModel::onQueryChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                placeholder = { Text(stringResource(R.string.search_placeholder)) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            )

            Box(modifier = Modifier.fillMaxSize()) {
                val currentState = state
                when (currentState) {
                    UiState.Empty -> {
                        if (query.isBlank()) {
                            EmptyState(message = stringResource(R.string.search_empty))
                        } else {
                            EmptyState(message = stringResource(R.string.search_no_results, query))
                        }
                    }
                    UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                    is UiState.Error -> ErrorState(message = currentState.message, onRetry = { viewModel.onQueryChange(query) })
                    is UiState.Success -> {
                        val data = currentState.data
                        LazyColumn(Modifier.fillMaxSize()) {
                            if (data.users.isNotEmpty()) {
                                item { SectionHeader(stringResource(R.string.search_results_users)) }
                                userItems(data.users, onUserClick)
                            }
                            if (data.posts.isNotEmpty()) {
                                item { SectionHeader(stringResource(R.string.search_results_posts)) }
                                postItems(data.posts, onPostClick)
                            }
                            if (data.articles.isNotEmpty()) {
                                item { SectionHeader(stringResource(R.string.search_results_articles)) }
                                articleItems(data.articles, onArticleClick)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun LazyListScope.userItems(users: List<UserProfileSummary>, onClick: (String) -> Unit) {
    items(users) { user ->
        UserRow(
            fullName = user.fullName,
            username = user.username,
            avatarColor = user.avatarColor,
            avatarUrl = user.avatarUrl,
            isVerified = user.isVerified,
            bio = user.bio,
            onClick = { onClick(user.username) },
        )
    }
}

private fun LazyListScope.postItems(posts: List<PostDto>, onClick: (String) -> Unit) {
    items(posts) { post ->
        PostSearchRow(post = post, onClick = { onClick(post.id) })
    }
}

private fun LazyListScope.articleItems(articles: List<ArticleCardDto>, onClick: (String) -> Unit) {
    items(articles) { article ->
        androidx.compose.material3.Card(
            onClick = { onClick(article.id) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
        ) {
            Column(Modifier.padding(12.dp)) {
                Text(article.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                if (!article.excerpt.isNullOrBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = article.excerpt,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "@${article.author.username}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
    )
}
