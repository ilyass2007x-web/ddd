package com.centrychat.android.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Search suggestions response — `GET /api/v1/search/suggest`.
 * Backend returns: `{"ok":true,"data":{"users":[...],"posts":[...],"articles":[...]}}`
 */
@Serializable
data class SuggestResponse(
    val users: List<UserProfileSummary> = emptyList(),
    val posts: List<PostDto> = emptyList(),
    val articles: List<ArticleCardDto> = emptyList(),
)

/**
 * Search history response — `GET /api/v1/search-history`.
 * Backend returns: `{"ok":true,"data":{"history":[{...}]}}`
 */
@Serializable
data class SearchHistoryResponse(
    val history: List<SearchHistoryItem> = emptyList(),
)

@Serializable
data class SearchHistoryItem(
    val id: String,
    val query: String,
    @SerialName("createdAt") val createdAt: String = "",
)

// ────────────────────────────────────────────────────────────────────
// Username check (registration form)
// ────────────────────────────────────────────────────────────────────

@Serializable
data class UsernameCheckRequest(
    val username: String,
)

/**
 * Response: `{"ok":true,"data":{"available":true,"suggestions":["..."]}}`
 */
@Serializable
data class UsernameCheckResponse(
    val available: Boolean = false,
    val suggestions: List<String> = emptyList(),
)

// ────────────────────────────────────────────────────────────────────
// Topics
// ────────────────────────────────────────────────────────────────────

@Serializable
data class TopicsListResponse(
    val topics: List<TopicDto> = emptyList(),
)

@Serializable
data class TopicDto(
    val id: String,
    val slug: String,
    val name: String,
    val description: String? = null,
    val isActive: Boolean = true,
    @SerialName("isFollowing") val isFollowing: Boolean = false,
    @SerialName("followersCount") val followersCount: Long = 0,
    @SerialName("postsCount") val postsCount: Long = 0,
    @SerialName("articlesCount") val articlesCount: Long = 0,
)

@Serializable
data class TopicDetailResponse(
    val topic: TopicDto,
)

// ────────────────────────────────────────────────────────────────────
// Collections (save-for-later of posts/articles/profiles)
// ────────────────────────────────────────────────────────────────────

@Serializable
data class CollectionsListResponse(
    val collections: List<CollectionDto> = emptyList(),
)

@Serializable
data class CollectionDto(
    val id: String,
    val name: String,
    val description: String? = null,
    val visibility: String = "PRIVATE",
    @SerialName("itemsCount") val itemsCount: Long = 0,
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("updatedAt") val updatedAt: String? = null,
)

@Serializable
data class CollectionItemsResponse(
    val items: List<CollectionItemDto> = emptyList(),
)

@Serializable
data class CollectionItemDto(
    val id: String,
    val itemType: String,
    val itemId: String,
    @SerialName("addedAt") val addedAt: String = "",
    // Polymorphic payload — only one populated depending on itemType
    val post: PostDto? = null,
    val article: ArticleCardDto? = null,
    val profile: UserProfileSummary? = null,
)

// ────────────────────────────────────────────────────────────────────
// Playlists (ordered list of articles)
// ────────────────────────────────────────────────────────────────────

@Serializable
data class PlaylistsListResponse(
    val playlists: List<PlaylistDto> = emptyList(),
)

@Serializable
data class PlaylistDto(
    val id: String,
    val name: String,
    val slug: String,
    val description: String? = null,
    val visibility: String = "PRIVATE",
    @SerialName("itemsCount") val itemsCount: Long = 0,
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("updatedAt") val updatedAt: String? = null,
)

@Serializable
data class PlaylistItemsResponse(
    val items: List<PlaylistItemDto> = emptyList(),
)

@Serializable
data class PlaylistItemDto(
    val id: String,
    val articleId: String,
    val position: Long = 0,
    val article: ArticleCardDto? = null,
)

// ────────────────────────────────────────────────────────────────────
// Public site pages (about / privacy / terms / contact)
// ────────────────────────────────────────────────────────────────────

@Serializable
data class SitePageResponse(
    val page: SitePageDto? = null,
)

@Serializable
data class SitePageDto(
    val slug: String,
    val title: String,
    val content: String = "",
    val visibility: String = "PUBLIC",
    @SerialName("seoTitle") val seoTitle: String? = null,
    @SerialName("seoDescription") val seoDescription: String? = null,
    @SerialName("publishedAt") val publishedAt: String? = null,
    @SerialName("updatedAt") val updatedAt: String? = null,
)

// ────────────────────────────────────────────────────────────────────
// Admin DTOs
// ────────────────────────────────────────────────────────────────────

/**
 * Admin dashboard — `GET /api/v1/admin/dashboard`.
 * Shape: `{"ok":true,"data":{...stats...}}`
 */
@Serializable
data class AdminDashboardResponse(
    val users: AdminUsersStats? = null,
    val content: AdminContentStats? = null,
    val moderation: AdminModerationStats? = null,
    val sessions: AdminSessionsStats? = null,
)

@Serializable
data class AdminUsersStats(
    val total: Long = 0,
    val active: Long = 0,
    val suspended: Long = 0,
    val banned: Long = 0,
    @SerialName("pending_verification") val pendingVerification: Long = 0,
    val newToday: Long = 0,
    val newThisWeek: Long = 0,
)

@Serializable
data class AdminContentStats(
    val posts: Long = 0,
    val articles: Long = 0,
    val pending: Long = 0,
    val flagged: Long = 0,
)

@Serializable
data class AdminModerationStats(
    val pending: Long = 0,
    val reviewed: Long = 0,
    val blocked: Long = 0,
)

@Serializable
data class AdminSessionsStats(
    val active: Long = 0,
    val last24h: Long = 0,
)

@Serializable
data class AdminUsersListResponse(
    val users: List<AdminUserSummary> = emptyList(),
    @SerialName("nextCursor") val nextCursor: String? = null,
    val total: Long = 0,
)

@Serializable
data class AdminUserSummary(
    val id: String,
    val fullName: String,
    val email: String? = null,
    val username: String = "",
    val role: String = "USER",
    val status: String = "ACTIVE",
    val isVerified: Boolean = false,
    @SerialName("avatarColor") val avatarColor: String? = null,
    @SerialName("avatarUrl") val avatarUrl: String? = null,
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("lastSeenAt") val lastSeenAt: String? = null,
)

@Serializable
data class AdminUserDetailResponse(
    val user: AdminUserDetail? = null,
)

@Serializable
data class AdminUserDetail(
    val id: String,
    val fullName: String,
    val email: String? = null,
    val username: String = "",
    val role: String = "USER",
    val status: String = "ACTIVE",
    val isVerified: Boolean = false,
    @SerialName("avatarColor") val avatarColor: String? = null,
    @SerialName("avatarUrl") val avatarUrl: String? = null,
    val bio: String? = null,
    val gender: String? = null,
    @SerialName("dateOfBirth") val dateOfBirth: String? = null,
    @SerialName("countryCode") val countryCode: String? = null,
    val language: String = "en",
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("lastSeenAt") val lastSeenAt: String? = null,
    @SerialName("twoFactorEnabled") val twoFactorEnabled: Boolean = false,
    val permissions: List<String> = emptyList(),
    @SerialName("moderationHistory") val moderationHistory: List<AdminModerationEvent> = emptyList(),
)

@Serializable
data class AdminModerationEvent(
    val id: String,
    val action: String,
    val reason: String? = null,
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("adminId") val adminId: String? = null,
)

@Serializable
data class AdminContentListResponse(
    val items: List<AdminContentItem> = emptyList(),
    @SerialName("nextCursor") val nextCursor: String? = null,
    val total: Long = 0,
)

@Serializable
data class AdminContentItem(
    val id: String,
    val type: String,
    val title: String? = null,
    val content: String? = null,
    val excerpt: String? = null,
    val status: String = "PUBLISHED",
    @SerialName("moderationStatus") val moderationStatus: String = "APPROVED",
    val author: AdminUserSummary? = null,
    @SerialName("createdAt") val createdAt: String = "",
    @SerialName("publishedAt") val publishedAt: String? = null,
)

@Serializable
data class AdminSettingsResponse(
    val settings: List<AdminSettingEntry> = emptyList(),
)

@Serializable
data class AdminSettingEntry(
    val key: String,
    val value: String? = null,
    val type: String = "string",
    val description: String? = null,
    val category: String? = null,
)

@Serializable
data class AdminFeaturesResponse(
    val features: List<AdminFeatureEntry> = emptyList(),
)

@Serializable
data class AdminFeatureEntry(
    val key: String,
    val enabled: Boolean = false,
    val description: String? = null,
)

@Serializable
data class AdminAuditListResponse(
    val logs: List<AdminAuditLog> = emptyList(),
    @SerialName("nextCursor") val nextCursor: String? = null,
    val total: Long = 0,
)

@Serializable
data class AdminAuditLog(
    val id: String,
    val action: String,
    @SerialName("adminId") val adminId: String? = null,
    @SerialName("adminName") val adminName: String? = null,
    @SerialName("targetType") val targetType: String? = null,
    @SerialName("targetId") val targetId: String? = null,
    val metadata: String? = null,
    @SerialName("ipAddress") val ipAddress: String? = null,
    @SerialName("createdAt") val createdAt: String = "",
)

@Serializable
data class AdminSystemResponse(
    val node: String? = null,
    val uptime: Long = 0,
    val memory: AdminSystemMemory? = null,
    val providers: AdminSystemProviders? = null,
)

@Serializable
data class AdminSystemMemory(
    val rss: Long = 0,
    val heapTotal: Long = 0,
    val heapUsed: Long = 0,
    val external: Long = 0,
)

@Serializable
data class AdminSystemProviders(
    val database: String = "unknown",
    val storage: String = "unknown",
    val email: String = "unknown",
    val cache: String = "unknown",
    val jobs: String = "unknown",
    val realtime: String = "unknown",
)

@Serializable
data class AdminSecurityResponse(
    val headers: Map<String, String> = emptyMap(),
    val rateLimits: Map<String, String> = emptyMap(),
    val audit: AdminSecurityAudit? = null,
)

@Serializable
data class AdminSecurityAudit(
    val totalEvents: Long = 0,
    val last24h: Long = 0,
    val recentActions: List<String> = emptyList(),
)

@Serializable
data class AdminMyPermissionsResponse(
    val role: String = "USER",
    val permissions: List<String> = emptyList(),
    val isSuperAdmin: Boolean = false,
)
