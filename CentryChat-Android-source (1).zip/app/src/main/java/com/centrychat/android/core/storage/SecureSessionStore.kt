package com.centrychat.android.core.storage

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Persistent, encrypted storage for session cookies + other secrets.
 *
 * WHY ENCRYPTED SHAREDPREFERENCES?
 *  - The session cookie (iron-session, name `messenger_session`) is the
 *    user's credential for accessing the CentryChat backend. If it leaks
 *    (e.g. via a backup, via an attacker with physical access to a rooted
 *    device), the attacker can impersonate the user for up to 7 days.
 *  - AndroidX Security's EncryptedSharedPreferences stores values at rest
 *    using AES-GCM 256-bit (key wrapped with a MasterKey tied to the
 *    Android keystore). Without the device unlock, the values are unreadable.
 *
 * CRASH-SAFETY (Root Cause #2 fix):
 *  - The previous version initialized `EncryptedSharedPreferences` lazily
 *    on the FIRST access (which happened during Application.onCreate() via
 *    PersistentCookieJar's constructor → loadFromDisk() → prefs.getString()).
 *    On some devices (Android 7-9 with a flaky keystore, or emulators with
 *    a broken keystore), `MasterKey.Builder.build()` throws
 *    `GeneralSecurityException` or `IOException`. Because this happened
 *    during Application.onCreate(), the exception killed the process
 *    immediately — manifesting as a black screen + crash on cold start.
 *  - The fix: catch every exception during init + fall back to a PLAIN
 *    SharedPreferences (named `centrychat_session_fallback`). This is
 *    strictly worse from a security standpoint (the cookie is no longer
 *    encrypted at rest), but it prevents a hard crash. The fallback is
 *    logged so the user / developer can detect it.
 *
 * This class is intentionally narrow — it only exposes the methods the app
 * needs (load/save cookies JSON, hasSession, clearSession). Adding more
 * "secret storage" here would expand the trust surface unnecessarily.
 */
class SecureSessionStore(
    private val context: Context,
) {
    /**
     * The resolved SharedPreferences. May be encrypted (preferred) or plain
     * (fallback). Callers don't need to know which — both implementations
     * expose the same `getString`/`edit().putString()` API.
     */
    private val prefs: SharedPreferences by lazy { resolvePrefsSafely() }

    /** Loads the JSON-serialized cookie map (or null if none stored). */
    fun loadCookiesJson(): String? {
        return try {
            prefs.getString(KEY_COOKIES, null)
        } catch (e: Exception) {
            Log.w(TAG, "Failed to read cookies from prefs: ${e.message}")
            null
        }
    }

    /** Persists the JSON-serialized cookie map. */
    fun saveCookiesJson(json: String) {
        try {
            prefs.edit().putString(KEY_COOKIES, json).apply()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to write cookies to prefs: ${e.message}")
        }
    }

    /** Whether the session cookie is currently stored. */
    suspend fun hasSession(): Boolean {
        return !loadCookiesJson().isNullOrEmpty()
    }

    /** Clears all session data (called on logout + on HTTP 401). */
    fun clearSession() {
        try {
            prefs.edit().remove(KEY_COOKIES).apply()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to clear session: ${e.message}")
        }
    }

    // ── Implementation ──────────────────────────────────────────────────

    /**
     * Resolves the SharedPreferences to use, preferring EncryptedSharedPreferences
     * but falling back to plain SharedPreferences on any failure.
     *
     * This function NEVER throws — it always returns a working SharedPreferences
     * instance. The fallback (plain) SharedPreferences is intentionally a
     * different file name so we don't accidentally read stale plaintext data
     * that a previous (broken) install may have written.
     */
    private fun resolvePrefsSafely(): SharedPreferences {
        // Try the encrypted prefs first.
        return try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context,
                ENCRYPTED_PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
            ).also {
                Log.i(TAG, "EncryptedSharedPreferences initialized successfully.")
            }
        } catch (e: Exception) {
            // CRITICAL: never propagate this exception. The previous version
            // let it bubble up, killing Application.onCreate() → black screen
            // + crash on cold start. Now we log + fall back to plain prefs.
            Log.e(TAG, "EncryptedSharedPreferences init FAILED — falling back to plain SharedPreferences. Cookie will NOT be encrypted at rest. Cause: ${e.javaClass.simpleName}: ${e.message}")
            context.getSharedPreferences(FALLBACK_PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    companion object {
        private const val TAG = "CentryChat/Session"
        private const val ENCRYPTED_PREFS_NAME = "centrychat_secure_session"
        private const val FALLBACK_PREFS_NAME = "centrychat_session_fallback"
        private const val KEY_COOKIES = "cookies_json"
    }
}
