package com.centrychat.android.feature.post_detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.ArticleDetailDto
import com.centrychat.android.data.repository.ArticlesRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Article detail screen ViewModel — loads a single article + handles the
 * toggleLike action.
 */
class ArticleDetailViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: ArticlesRepository = appContainer.articlesRepository

    private val _state = MutableStateFlow<UiState<ArticleDetailDto>>(UiState.Loading)
    val state: StateFlow<UiState<ArticleDetailDto>> = _state.asStateFlow()

    fun loadArticle(articleId: String) {
        _state.value = UiState.Loading
        viewModelScope.launch {
            try {
                val article = repo.getArticle(articleId)
                _state.value = UiState.Success(article)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = UiState.Error(e.message ?: "Could not load article.")
            }
        }
    }

    fun toggleLike(articleId: String) {
        viewModelScope.launch {
            try {
                val result = repo.toggleLike(articleId)
                val current = (_state.value as? UiState.Success)?.data ?: return@launch
                _state.value = UiState.Success(
                    current.copy(isLiked = result.liked, likeCount = result.likeCount)
                )
            } catch (_: Exception) {
                // best-effort
            }
        }
    }
}
