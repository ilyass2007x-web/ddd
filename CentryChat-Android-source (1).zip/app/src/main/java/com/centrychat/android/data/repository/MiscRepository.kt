package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.SearchHistoryResponse
import com.centrychat.android.data.model.SitePageResponse
import com.centrychat.android.data.model.SuggestResponse
import com.centrychat.android.data.model.UsernameCheckRequest
import com.centrychat.android.data.model.UsernameCheckResponse
import com.centrychat.android.data.model.safeApiCall

/**
 * Misc repository — wraps assorted endpoints that don't fit elsewhere:
 *  - Search suggestions + history (`/api/v1/search/suggest`, `/api/v1/search-history`)
 *  - Username availability check (`/api/v1/username-check`)
 *  - Public site pages (about / privacy / terms / contact) (`/api/v1/site-pages/{slug}`)
 *  - Block / Unblock users (`/api/v1/users/{username}/block`)
 *  - Not-interested (feed dismiss) (`/api/v1/not-interested`)
 *  - View tracking + presence heartbeat (`/api/v1/interactions`, `/api/v1/presence/heartbeat`)
 */
class MiscRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** Search suggestions (autocomplete across users + posts + articles). */
    suspend fun suggest(query: String, limit: Int = 10): SuggestResponse =
        safeApiCall { api.searchSuggest(query = query, limit = limit) }

    /** Fetch the user's recent search history. */
    suspend fun getSearchHistory(): SearchHistoryResponse =
        safeApiCall { api.getSearchHistory() }

    /** Clear all search history. */
    suspend fun clearSearchHistory(): Boolean {
        safeApiCall { api.clearSearchHistory(origin = origin) }
        return true
    }

    /** Check username availability during registration.
     *  Public endpoint, no Origin header needed (no session). */
    suspend fun checkUsername(username: String): UsernameCheckResponse =
        safeApiCall { api.checkUsername(body = UsernameCheckRequest(username = username)) }

    /** Fetch a public site page (about / privacy / terms / contact). */
    suspend fun getSitePage(slug: String): SitePageResponse =
        safeApiCall { api.getSitePage(slug) }

    /** Block a user — they can no longer DM or follow the current user. */
    suspend fun blockUser(username: String): Boolean {
        safeApiCall { api.blockUser(username = username, origin = origin) }
        return true
    }

    /** Unblock a user. */
    suspend fun unblockUser(username: String): Boolean {
        safeApiCall { api.unblockUser(username = username, origin = origin) }
        return true
    }

    /** Mark a feed item as "not interested" — strong negative signal for the
     *  recommendation engine (reduces similar content in future feed). */
    suspend fun markNotInterested(contentType: String, contentId: String): Boolean {
        val body = mapOf<String, String?>(
            "contentType" to contentType,
            "contentId" to contentId,
        )
        safeApiCall { api.markNotInterested(body = body, origin = origin) }
        return true
    }

    /** Track a user interaction (view / like / share / etc.) — feeds the
     *  user's interest profile for the personalized feed. Best-effort,
     *  no error surface (failures are silent). */
    suspend fun trackInteraction(
        contentType: String,
        contentId: String,
        action: String,
    ): Boolean {
        val body = mapOf<String, String?>(
            "contentType" to contentType,
            "contentId" to contentId,
            "action" to action,
        )
        return try {
            safeApiCall { api.trackInteraction(body = body, origin = origin) }
            true
        } catch (_: Exception) {
            false
        }
    }

    /** Presence heartbeat — updates the user's lastSeenAt. Best-effort,
     *  no error surface. The web client sends this every 30s while the
     *  tab is visible; on Android, the foreground service / lifecycle
     *  observer would do the same. */
    suspend fun heartbeat(): Boolean {
        return try {
            safeApiCall { api.heartbeat(origin = origin) }
            true
        } catch (_: Exception) {
            false
        }
    }
}
