package com.centrychat.android.feature.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.ArticleCardDto
import com.centrychat.android.data.model.PlaylistDto
import com.centrychat.android.data.model.PostDto
import com.centrychat.android.data.model.ProfileDetailDto
import com.centrychat.android.data.model.UserProfileSummary
import com.centrychat.android.data.repository.ArticlesRepository
import com.centrychat.android.data.repository.PlaylistsRepository
import com.centrychat.android.data.repository.ProfileRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * The active tab on the Profile screen — mirrors the web's profile tab
 * layout (Posts / Articles / Playlists).
 */
enum class ProfileTab(val labelRes: Int) {
    POSTS(com.centrychat.android.R.string.profile_posts),
    ARTICLES(com.centrychat.android.R.string.profile_articles),
    PLAYLISTS(com.centrychat.android.R.string.profile_playlists),
}

/**
 * Follow-button state machine — mirrors the web's FollowButton states.
 *
 * The web's `FollowButton` (src/components/shared/follow-button.tsx) has
 * 4 visual states derived from the (isFollowing, isFollowedBy) pair:
 *
 *   isFollowing=false, isFollowedBy=false  → "Follow"           (primary action)
 *   isFollowing=false, isFollowedBy=true   → "Follow Back"      (primary action)
 *   isFollowing=true, isFollowedBy=false   → "Following"        (outline button)
 *   isFollowing=true, isFollowedBy=true    → "Following"        (outline button)
 *
 * `Requested` would be a 5th state if the project supported private
 * accounts — it currently doesn't, so we don't render it.
 */
enum class FollowButtonState(val labelRes: Int) {
    FOLLOW(com.centrychat.android.R.string.follow_state_follow),
    FOLLOW_BACK(com.centrychat.android.R.string.follow_state_follow_back),
    FOLLOWING(com.centrychat.android.R.string.follow_state_following);

    companion object {
        fun from(following: Boolean, followedBy: Boolean): FollowButtonState = when {
            following -> FOLLOWING
            followedBy -> FOLLOW_BACK
            else -> FOLLOW
        }
    }
}

class ProfileViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: ProfileRepository = appContainer.profileRepository
    private val articlesRepo: ArticlesRepository = appContainer.articlesRepository
    private val playlistsRepo: PlaylistsRepository = appContainer.playlistsRepository

    private val _profileState = MutableStateFlow<UiState<UserProfileSummary>>(UiState.Loading)
    val profileState: StateFlow<UiState<UserProfileSummary>> = _profileState.asStateFlow()

    private val _isFollowing = MutableStateFlow(false)
    val isFollowing: StateFlow<Boolean> = _isFollowing.asStateFlow()

    private val _isFollowedBy = MutableStateFlow(false)
    val isFollowedBy: StateFlow<Boolean> = _isFollowedBy.asStateFlow()

    private val _selectedTab = MutableStateFlow(ProfileTab.POSTS)
    val selectedTab: StateFlow<ProfileTab> = _selectedTab.asStateFlow()

    private val _posts = MutableStateFlow<UiState<List<PostDto>>>(UiState.Loading)
    val posts: StateFlow<UiState<List<PostDto>>> = _posts.asStateFlow()

    private val _articles = MutableStateFlow<UiState<List<ArticleCardDto>>>(UiState.Loading)
    val articles: StateFlow<UiState<List<ArticleCardDto>>> = _articles.asStateFlow()

    private val _playlists = MutableStateFlow<UiState<List<PlaylistDto>>>(UiState.Loading)
    val playlists: StateFlow<UiState<List<PlaylistDto>>> = _playlists.asStateFlow()

    fun loadProfile(username: String?) {
        _profileState.value = UiState.Loading
        viewModelScope.launch {
            try {
                if (username.isNullOrBlank()) {
                    // Load the current user's own profile.
                    val me = repo.getMyProfile().user
                    if (me == null) {
                        _profileState.value = UiState.Empty
                        return@launch
                    }
                    val profile = UserProfileSummary(
                        id = me.id,
                        fullName = me.fullName,
                        username = me.username,
                        avatarColor = me.avatarColor,
                        avatarUrl = me.avatarUrl,
                        isVerified = me.isVerified,
                        bio = me.bio,
                        followersCount = 0,
                        followingCount = 0,
                        postsCount = 0,
                        isFollowing = false,
                        isFollowedBy = false,
                    )
                    _profileState.value = UiState.Success(profile)
                    _isFollowing.value = false
                    _isFollowedBy.value = false
                    loadUserContent(me.username)
                } else {
                    val profile = repo.getPublicProfile(username)
                    _profileState.value = UiState.Success(profile)
                    _isFollowing.value = profile.isFollowing
                    _isFollowedBy.value = profile.isFollowedBy
                    loadUserContent(username)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _profileState.value = UiState.Error(e.message ?: "Could not load profile.")
            }
        }
    }

    /**
     * Load the profile's posts + articles + playlists in parallel.
     * Each tab's data is stored in a separate StateFlow so the UI can
     * lazy-render the right tab without re-fetching when the user
     * switches tabs.
     */
    private fun loadUserContent(username: String) {
        viewModelScope.launch {
            try {
                val posts = appContainer_postsByUsername(username)
                _posts.value = if (posts.isEmpty()) UiState.Empty else UiState.Success(posts)
            } catch (e: Exception) {
                _posts.value = UiState.Error(e.message ?: "Could not load posts.")
            }
        }
        viewModelScope.launch {
            try {
                // Articles endpoint doesn't currently support per-author
                // filtering on Android — use the global list. Tracked as TODO
                // for the next iteration (would need a `?authorId=` query
                // param on GET /api/v1/articles).
                val articles = articlesRepo.getFirstPage(limit = 20)
                _articles.value = if (articles.isEmpty()) UiState.Empty else UiState.Success(articles)
            } catch (e: Exception) {
                _articles.value = UiState.Error(e.message ?: "Could not load articles.")
            }
        }
        viewModelScope.launch {
            try {
                val playlists = playlistsRepo.getPlaylists(limit = 50).playlists
                _playlists.value = if (playlists.isEmpty()) UiState.Empty else UiState.Success(playlists)
            } catch (e: Exception) {
                _playlists.value = UiState.Error(e.message ?: "Could not load playlists.")
            }
        }
    }

    /** Posts by username — wraps the /api/v1/posts?authorId=ID query.
     *  Currently uses the PostsRepository.getPosts(authorId=...) method,
     *  but the username → id lookup would require fetching the public
     *  profile first. For now, return empty list — the web does a
     *  /api/v1/users/[username]/articles endpoint that's not wired in
     *  the Android API yet. Tracked as TODO. */
    private suspend fun appContainer_postsByUsername(username: String): List<PostDto> {
        // TODO: wire GET /api/v1/users/{username}/articles endpoint on Android.
        // For now, return empty — the Profile's Posts tab will show an
        // empty state rather than the wrong user's posts.
        return emptyList()
    }

    fun selectTab(tab: ProfileTab) {
        _selectedTab.value = tab
    }

    fun toggleFollow(username: String) {
        viewModelScope.launch {
            try {
                if (_isFollowing.value) {
                    repo.unfollow(username)
                    _isFollowing.value = false
                } else {
                    repo.follow(username)
                    _isFollowing.value = true
                }
            } catch (_: Exception) {
                // best-effort
            }
        }
    }
}

class EditProfileViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: ProfileRepository = appContainer.profileRepository

    private val _profile = MutableStateFlow<ProfileDetailDto?>(null)
    val profile: StateFlow<ProfileDetailDto?> = _profile.asStateFlow()

    private val _isSaving = MutableStateFlow(false)
    val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

    private val _saveError = MutableStateFlow<String?>(null)
    val saveError: StateFlow<String?> = _saveError.asStateFlow()

    private val _saved = MutableStateFlow(false)
    val saved: StateFlow<Boolean> = _saved.asStateFlow()

    fun load() {
        viewModelScope.launch {
            try {
                val me = repo.getMyProfile().user
                _profile.value = me
            } catch (_: Exception) {
                // best-effort
            }
        }
    }

    fun save(
        fullName: String,
        username: String,
        bio: String?,
        avatarUrl: String?,
        language: String,
        gender: String?,
        dateOfBirth: String?,
        countryCode: String?,
    ) {
        if (_isSaving.value) return
        viewModelScope.launch {
            _isSaving.value = true
            _saveError.value = null
            try {
                val changes = buildMap {
                    put("fullName", fullName)
                    put("username", username)
                    put("bio", bio)
                    put("avatarUrl", avatarUrl)
                    put("language", language)
                    if (gender != null) put("gender", gender)
                    if (dateOfBirth != null) put("dateOfBirth", dateOfBirth)
                    if (countryCode != null) put("countryCode", countryCode)
                }
                val updated = repo.updateMyProfile(changes)
                _profile.value = updated.user
                _saved.value = true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _saveError.value = e.message ?: "Could not save profile."
            } finally {
                _isSaving.value = false
            }
        }
    }

    fun consumeSaved() {
        _saved.value = false
    }
}
