package com.centrychat.android.feature.splash

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.centrychat.android.R
import com.centrychat.android.core.AppContainer
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull

/**
 * A brief cold-start screen.
 *
 * Renders the CentryChat brand mark (lucide MessageSquareLock, identical to
 * the website's favicon) + the platform name + a small spinner. Verifies the
 * local session cookie against the backend by calling `/api/v1/auth/me`:
 *   - On success → navigates to the home feed.
 *   - On failure / no cookie / timeout → navigates to the login screen.
 *
 * CRASH-SAFETY (Root Cause #3 fix):
 *  - The previous version called `fetchCurrentUser()` without a timeout —
 *    on a slow network (or no network), the splash could hang indefinitely
 *    on a black screen. The user would force-kill the app.
 *  - The fix wraps the call in `withTimeoutOrNull(3_500ms)`. After 3.5
 *    seconds, regardless of the network state, the splash navigates to
 *    the login screen so the user is never stuck on a black screen.
 *  - The splash ALSO renders the brand mark immediately (before the
 *    network call completes) so the user always sees something on the
 *    screen within the first frame — never a black screen.
 *
 * This screen is the start destination of the NavHost — see
 * [com.centrychat.android.navigation.CentryChatRoot].
 */
@Composable
fun SplashScreen(
    appContainer: AppContainer,
    onSessionAlive: () -> Unit,
    onSessionDead: () -> Unit,
) {
    // Verify the session + navigate, with a hard timeout so we never hang.
    LaunchedEffect(appContainer) {
        // Hard timeout — even if the network is completely broken, we
        // navigate to login after 3.5 seconds. The user is never stuck.
        val user = withTimeoutOrNull(3_500L) {
            try {
                appContainer.authRepository.fetchCurrentUser()
            } catch (_: Exception) {
                null
            }
        }
        if (user != null) {
            onSessionAlive()
        } else {
            onSessionDead()
        }
    }

    // Render the brand mark IMMEDIATELY so the user always sees the logo
    // within the first frame — never a black screen.
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            // The CentryChat brand mark — lucide MessageSquareLock, same
            // icon as the website's favicon (src/app/icon.svg).
            Image(
                painter = painterResource(R.drawable.ic_brand_logo),
                contentDescription = null,
                modifier = Modifier.size(96.dp),
            )
            Spacer(Modifier.height(16.dp))
            Text(
                text = "CentryChat",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
            )
            Spacer(Modifier.height(24.dp))
            // Small spinner — visible only during the brief session check.
            CircularProgressIndicator(
                color = MaterialTheme.colorScheme.primary,
                strokeWidth = 2.dp,
                modifier = Modifier.size(24.dp),
            )
        }
    }
}
