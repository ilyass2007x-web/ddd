package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.ArticleCardDto
import com.centrychat.android.data.model.ArticleDetailDto
import com.centrychat.android.data.model.ArticleListResponse
import com.centrychat.android.data.model.ToggleLikeResponse
import com.centrychat.android.data.model.safeApiCall

/**
 * Articles repository.
 *
 * Wraps the article list + article detail + article-like endpoints.
 *
 * ERROR HANDLING: every API call goes through [safeApiCall] which extracts
 * the structured `error.message` from non-2xx responses (e.g. "Article not
 * found." on a 404). Without this, the ViewModel would display a generic
 * "HTTP 404 ..." string from Retrofit's default HttpException message.
 *
 * ARTICLE DETAIL UNWRAPPING: the backend wraps the article detail under
 * `data.article` (NOT directly under `data`), so the API interface returns
 * [com.centrychat.android.data.model.ArticleDetailResponse] and we extract
 * `.article` here. See the ArticleDetailResponse KDoc for the rationale.
 */
class ArticlesRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** Fetch a paginated list of published articles. */
    suspend fun getArticles(cursor: String? = null, limit: Int = 10): ArticleListResponse {
        return safeApiCall { api.getArticles(limit = limit, cursor = cursor) }
    }

    /** Fetch a single article by ID (includes the full content body).
     *
     *  The backend wraps the article under `data.article`, so we unwrap
     *  it via [ArticleDetailResponse.article]. See the ArticleDetailResponse
     *  KDoc for the rationale. */
    suspend fun getArticle(id: String): ArticleDetailDto {
        return safeApiCall { api.getArticle(id) }.article
    }

    /** Toggle like on an article. */
    suspend fun toggleLike(id: String): ToggleLikeResponse {
        return safeApiCall { api.toggleArticleLike(id = id, origin = origin) }
    }

    /** Convenience: fetch the first page of articles as a flat list. */
    suspend fun getFirstPage(limit: Int = 10): List<ArticleCardDto> {
        return getArticles(cursor = null, limit = limit).articles
    }
}
